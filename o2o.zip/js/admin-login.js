// Admin Login JavaScript
document.addEventListener('DOMContentLoaded', function() {
    // Toggle password visibility
    const togglePassword = document.getElementById('togglePassword');
    const passwordInput = document.getElementById('adminPassword');
    
    togglePassword.addEventListener('click', function() {
        const type = passwordInput.getAttribute('type') === 'password' ? 'text' : 'password';
        passwordInput.setAttribute('type', type);
        this.innerHTML = type === 'password' ? '<i class="fas fa-eye"></i>' : '<i class="fas fa-eye-slash"></i>';
    });
    
    // Admin login form submission
    document.getElementById('adminLoginForm').addEventListener('submit', function(e) {
        e.preventDefault();
        
        const username = document.getElementById('adminUsername').value;
        const password = document.getElementById('adminPassword').value;
        const secretKey = document.getElementById('adminSecretKey').value;
        
        // Default admin credentials (for demo)
        const defaultAdmin = {
            username: 'admin',
            password: 'admin123',
            secretKey: 'FH2023@ADMIN'
        };
        
        // Check credentials
        if (username === defaultAdmin.username && 
            password === defaultAdmin.password && 
            secretKey === defaultAdmin.secretKey) {
            
            // Save admin session
            localStorage.setItem('adminLoggedIn', 'true');
            localStorage.setItem('adminUsername', username);
            
            // Redirect to admin panel
            window.location.href = 'admin.html';
        } else {
            alert('Invalid credentials. Please try again.');
        }
    });
    
    // Check if already logged in
    if (localStorage.getItem('adminLoggedIn') === 'true') {
        window.location.href = 'admin.html';
    }
    // ADMIN PANEL FIX - Save to BOTH places
function saveToBothPlaces() {
    // 1. Save to admin storage
    localStorage.setItem('fashionHubProducts', JSON.stringify(adminData.products));
    localStorage.setItem('fashionHubShops', JSON.stringify(adminData.shops));
    
    // 2. ALSO save to website storage (IMPORTANT!)
    localStorage.setItem('websiteProducts', JSON.stringify(adminData.products));
    localStorage.setItem('websiteShops', JSON.stringify(adminData.shops));
    
    // 3. Set update timestamp
    localStorage.setItem('lastAdminUpdate', Date.now().toString());
    localStorage.setItem('forceWebsiteUpdate', 'true');
    
    // 4. Trigger storage event
    const event = new StorageEvent('storage', {
        key: 'fashionHubProducts',
        newValue: Date.now().toString()
    });
    window.dispatchEvent(event);
    
    console.log('💾 Data saved to BOTH admin and website storage!');
}

// Use this function after EVERY add/edit/delete operation
// Example: After adding product
function addProductWithSync(productData) {
    // ... your existing add product code ...
    
    // After adding, call:
    saveToBothPlaces();
    
    // Show message to user
    alert('✅ Product added! It will appear on website immediately.');
}
});