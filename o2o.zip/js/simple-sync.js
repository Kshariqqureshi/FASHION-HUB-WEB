// simple-sync.js - No database needed
class SimpleDataSync {
    constructor() {
        this.KEY_PRODUCTS = 'fashionHubProducts';
        this.KEY_SHOPS = 'fashionHubShops';
        this.initSampleData();
    }
    
    initSampleData() {
        // Add sample data if none exists
        if (!localStorage.getItem(this.KEY_PRODUCTS)) {
            const sampleProducts = [
                {
                    id: 1,
                    name: "Men's Formal Shirt",
                    shop_id: 1,
                    shop_name: "Trendy Fashions",
                    owner_name: "Rahul Verma",
                    location_area: "Civil Lines",
                    price: 1299,
                    category: "men",
                    image_url: "https://images.unsplash.com/photo-1596755094514-f87e34085b2c?ixlib=rb-4.0.3&auto=format&fit=crop&w=500&q=80",
                    phone: "9876543210",
                    whatsapp: "9876543210",
                    distance: 0.8,
                    created_at: new Date().toISOString()
                }
            ];
            localStorage.setItem(this.KEY_PRODUCTS, JSON.stringify(sampleProducts));
        }
        
        if (!localStorage.getItem(this.KEY_SHOPS)) {
            const sampleShops = [
                {
                    id: 1,
                    name: "Trendy Fashions",
                    owner_name: "Rahul Verma",
                    address: "Shop No. 12, Crossroad Mall, Civil Lines, Bareilly",
                    location_area: "Civil Lines",
                    location_code: "civil",
                    distance_km: 0.8,
                    phone: "9876543210",
                    whatsapp: "9876543210",
                    shop_type: "boutique",
                    category: "men",
                    created_at: new Date().toISOString()
                }
            ];
            localStorage.setItem(this.KEY_SHOPS, JSON.stringify(sampleShops));
        }
    }
    
    // Get all products
    getProducts() {
        const products = localStorage.getItem(this.KEY_PRODUCTS);
        return products ? JSON.parse(products) : [];
    }
    
    // Get all shops
    getShops() {
        const shops = localStorage.getItem(this.KEY_SHOPS);
        return shops ? JSON.parse(shops) : [];
    }
    
    // Add new shop
    addShop(shopData) {
        const shops = this.getShops();
        const newShop = {
            id: Date.now(),
            ...shopData,
            created_at: new Date().toISOString()
        };
        shops.push(newShop);
        localStorage.setItem(this.KEY_SHOPS, JSON.stringify(shops));
        
        // Trigger event for website
        this.triggerDataUpdate();
        
        return {
            success: true,
            message: 'Shop added successfully!',
            shop_id: newShop.id
        };
    }
    
    // Add new product
    addProduct(productData) {
        const products = this.getProducts();
        const shops = this.getShops();
        const shop = shops.find(s => s.id === productData.shop_id);
        
        const newProduct = {
            id: Date.now(),
            ...productData,
            shop_name: shop?.name || 'Unknown Shop',
            owner_name: shop?.owner_name || 'Unknown Owner',
            location_area: shop?.location_area || 'Unknown Location',
            phone: shop?.phone || '0000000000',
            whatsapp: shop?.whatsapp || '0000000000',
            distance: shop?.distance_km || 1.5,
            created_at: new Date().toISOString()
        };
        
        products.push(newProduct);
        localStorage.setItem(this.KEY_PRODUCTS, JSON.stringify(products));
        
        // Trigger event for website
        this.triggerDataUpdate();
        
        return {
            success: true,
            message: 'Product added successfully!',
            product_id: newProduct.id
        };
    }
    
    // Trigger data update event
    triggerDataUpdate() {
        // Update timestamp
        localStorage.setItem('lastDataUpdate', Date.now().toString());
        
        // Dispatch storage event (works across tabs)
        window.dispatchEvent(new StorageEvent('storage', {
            key: 'fashionHubDataUpdated',
            newValue: Date.now().toString()
        }));
        
        console.log('Data updated, website should refresh');
    }
}

// Create global instance
window.simpleSync = new SimpleDataSync();