// Product Display System
document.addEventListener('DOMContentLoaded', function() {
    // Wait for page to load
    setTimeout(initializeProductDisplay, 500);
});

function initializeProductDisplay() {
    console.log("🛒 Initializing product display system...");
    
    // Display products from admin data
    displayProductsFromAdmin();
    
    // Listen for admin data updates
    window.addEventListener('storage', function(e) {
        if (e.key === 'dataUpdated' || e.key === 'fashionHubProducts' || e.key === 'websiteProducts') {
            console.log("🔄 Admin data updated, refreshing products...");
            displayProductsFromAdmin();
        }
    });
    
    // Also check for data changes every 3 seconds (fallback)
    setInterval(checkForNewProducts, 3000);
}

function displayProductsFromAdmin() {
    const container = document.getElementById('productsContainer');
    const countElement = document.getElementById('product-count');
    
    if (!container) {
        console.error("❌ Products container not found!");
        return;
    }
    
    // Get products from localStorage (try multiple keys for compatibility)
    let products = [];
    
    // Try different localStorage keys
    const keysToTry = ['fashionHubProducts', 'websiteProducts'];
    for (const key of keysToTry) {
        const data = localStorage.getItem(key);
        if (data) {
            try {
                products = JSON.parse(data);
                console.log(`✅ Loaded ${products.length} products from ${key}`);
                break;
            } catch(e) {
                console.error(`❌ Error parsing ${key}:`, e);
            }
        }
    }
    
    // Get shops data too
    let shops = [];
    const shopsData = localStorage.getItem('fashionHubShops') || localStorage.getItem('websiteShops');
    if (shopsData) {
        try {
            shops = JSON.parse(shopsData);
        } catch(e) {
            console.error("Error parsing shops data:", e);
        }
    }
    
    // Update count
    if (countElement) {
        countElement.textContent = `${products.length} products available`;
    }
    
    // Display products
    if (products.length === 0) {
        container.innerHTML = `
            <div style="text-align: center; padding: 60px 20px; width: 100%;">
                <div style="font-size: 64px; color: #ddd; margin-bottom: 20px;">
                    <i class="fas fa-tshirt"></i>
                </div>
                <h3 style="color: #666; margin-bottom: 10px;">No products yet</h3>
                <p style="color: #888;">Products will appear here once added from the admin panel.</p>
                <a href="admin.html" style="display: inline-block; margin-top: 20px; background: #8e44ad; color: white; padding: 10px 20px; border-radius: 5px; text-decoration: none;">
                    <i class="fas fa-user-shield"></i> Go to Admin Panel
                </a>
            </div>
        `;
        return;
    }
    
    // Build products HTML
    let html = '';
    
    products.forEach(product => {
        // Find shop details
        const shop = shops.find(s => s.id === product.shop_id) || product;
        
        // Ensure image URL exists
        let imageUrl = product.image_url || product.image;
        if (!imageUrl) {
            // Fallback to random fashion image
            const fallbackImages = [
                "https://images.unsplash.com/photo-1596755094514-f87e34085b2c?ixlib=rb-4.0.3&auto=format&fit=crop&w=500&q=80",
                "https://images.unsplash.com/photo-1621072156002-e2fccdc0b176?ixlib=rb-4.0.3&auto=format&fit=crop&w=500&q=80",
                "https://images.unsplash.com/photo-1542272604-787c3835535d?ixlib=rb-4.0.3&auto=format&fit=crop&w=500&q=80",
                "https://images.unsplash.com/photo-1582418702059-97ebafb35d09?ixlib=rb-4.0.3&auto=format&fit=crop&w=500&q=80"
            ];
            const randomIndex = Math.floor(Math.random() * fallbackImages.length);
            imageUrl = fallbackImages[randomIndex];
        }
        
        // Format price
        const price = product.price ? `₹${product.price}` : 'Price not set';
        
        // Format category
        const category = product.category || 'General';
        const categoryMap = {
            'men': "Men's Fashion",
            'women': "Women's Fashion",
            'footwear': "Footwear",
            'kids': "Kids Wear",
            'accessories': "Accessories",
            'all': "All Products"
        };
        const categoryText = categoryMap[category] || category;
        
        // Create product card HTML (matching your image example)
        html += `
            <div class="product-card" data-product-id="${product.id}">
                <div class="product-badge">${categoryText}</div>
                <div class="product-image-container">
                    <img src="${imageUrl}" alt="${product.name}" class="product-image" 
                         onerror="this.src='https://via.placeholder.com/300x180/8e44ad/ffffff?text=FASHION'">
                </div>
                
                <div class="product-info">
                    <h3 class="product-title">${product.name || 'Product Name'}</h3>
                    
                    <div class="product-price">${price}</div>
                    
                    <div class="product-shop">
                        <i class="fas fa-store"></i>
                        <span>${shop.name || product.shop_name || 'Local Shop'}</span>
                    </div>
                    
                    <div class="product-location">
                        <i class="fas fa-map-marker-alt"></i>
                        <span>${shop.location_area || product.location_area || 'Bareilly'}</span>
                    </div>
                    
                    <div class="product-owner">
                        <i class="fas fa-user"></i> ${shop.owner_name || shop.owner || 'Shop Owner'}
                    </div>
                    
                    <div class="product-actions">
                        <button class="btn-chat" onclick="chatOnWhatsApp('${shop.whatsapp || shop.phone || ''}', '${product.name}')">
                            <i class="fab fa-whatsapp"></i> Chat on WhatsApp
                        </button>
                        <button class="btn-call" onclick="callShop('${shop.phone || ''}')">
                            <i class="fas fa-phone"></i>
                        </button>
                    </div>
                </div>
            </div>
        `;
    });
    
    container.innerHTML = html;
    
    // Add category filtering
    setupCategoryFiltering();
}

function setupCategoryFiltering() {
    const categoryLinks = document.querySelectorAll('.categories a');
    
    categoryLinks.forEach(link => {
        link.addEventListener('click', function(e) {
            e.preventDefault();
            
            // Update active link
            categoryLinks.forEach(l => l.classList.remove('active'));
            this.classList.add('active');
            
            // Get selected category
            const selectedCategory = this.getAttribute('data-category');
            
            // Update section title
            const titleElement = document.getElementById('sectionTitle');
            if (titleElement) {
                const categoryMap = {
                    'all': "Fashion Products in Bareilly",
                    'men': "Men's Fashion in Bareilly",
                    'women': "Women's Fashion in Bareilly",
                    'footwear': "Footwear in Bareilly",
                    'kids': "Kids Wear in Bareilly",
                    'accessories': "Accessories in Bareilly"
                };
                titleElement.textContent = categoryMap[selectedCategory] || "Fashion Products in Bareilly";
            }
            
            // Filter products
            filterProductsByCategory(selectedCategory);
        });
    });
}

function filterProductsByCategory(category) {
    const productCards = document.querySelectorAll('.product-card');
    
    if (category === 'all') {
        productCards.forEach(card => {
            card.style.display = 'block';
        });
        return;
    }
    
    productCards.forEach(card => {
        const badge = card.querySelector('.product-badge');
        const badgeText = badge.textContent.toLowerCase();
        
        if (badgeText.includes(category.toLowerCase()) || 
            (category === 'men' && badgeText.includes("men's")) ||
            (category === 'women' && badgeText.includes("women's"))) {
            card.style.display = 'block';
        } else {
            card.style.display = 'none';
        }
    });
}

function chatOnWhatsApp(phoneNumber, productName) {
    if (!phoneNumber || phoneNumber === 'undefined') {
        alert('WhatsApp number not available for this shop');
        return;
    }
    
    // Format message
    const message = `Hi, I'm interested in your product: ${productName}. Please share more details.`;
    const encodedMessage = encodeURIComponent(message);
    const whatsappUrl = `https://wa.me/91${phoneNumber}?text=${encodedMessage}`;
    
    // Open WhatsApp in new tab
    window.open(whatsappUrl, '_blank');
}

function callShop(phoneNumber) {
    if (!phoneNumber || phoneNumber === 'undefined') {
        alert('Phone number not available for this shop');
        return;
    }
    
    // Use tel: protocol for mobile, fallback to alert for desktop
    if (/Android|iPhone|iPad|iPod|BlackBerry|IEMobile|Opera Mini/i.test(navigator.userAgent)) {
        window.location.href = `tel:+91${phoneNumber}`;
    } else {
        alert(`Call this number: +91 ${phoneNumber}`);
    }
}

function checkForNewProducts() {
    // Check if products count changed
    const currentProducts = JSON.parse(localStorage.getItem('fashionHubProducts') || '[]');
    const lastCount = parseInt(localStorage.getItem('lastProductCount') || '0');
    
    if (currentProducts.length !== lastCount) {
        console.log(`🔄 Product count changed: ${lastCount} → ${currentProducts.length}`);
        displayProductsFromAdmin();
        localStorage.setItem('lastProductCount', currentProducts.length.toString());
    }
}

// Add these functions to your admin.js file too (for immediate updates)
function updateWebsiteData() {
    console.log("📤 Updating website data...");
    
    // Save to BOTH keys for compatibility
    localStorage.setItem('fashionHubProducts', JSON.stringify(adminData.products));
    localStorage.setItem('websiteProducts', JSON.stringify(adminData.products));
    localStorage.setItem('fashionHubShops', JSON.stringify(adminData.shops));
    localStorage.setItem('websiteShops', JSON.stringify(adminData.shops));
    
    // Trigger update signal
    localStorage.setItem('dataUpdated', Date.now().toString());
    localStorage.setItem('lastProductCount', adminData.products.length.toString());
    
    // Force a storage event
    window.dispatchEvent(new StorageEvent('storage', {
        key: 'dataUpdated',
        newValue: Date.now().toString()
    }));
    
    console.log('✅ Website data updated successfully!');
}