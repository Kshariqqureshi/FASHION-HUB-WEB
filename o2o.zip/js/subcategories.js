// subcategories.js - Subcategory Management System

class SubcategoryManager {
    constructor() {
        this.subcategories = {
            'new_arrival': [],
            'trending': [],
            'discount': [],
            'featured': []
        };
        this.init();
    }

    init() {
        this.loadSubcategories();
        this.setupEventListeners();
        this.renderSubcategoryFilters();
    }

    loadSubcategories() {
        const saved = localStorage.getItem('fashionHubSubcategories');
        if (saved) {
            this.subcategories = JSON.parse(saved);
        }
    }

    saveSubcategories() {
        localStorage.setItem('fashionHubSubcategories', JSON.stringify(this.subcategories));
    }

    assignToSubcategory(productId, subcategory) {
        // Remove from all other subcategories first
        Object.keys(this.subcategories).forEach(key => {
            this.subcategories[key] = this.subcategories[key].filter(id => id !== productId);
        });
        
        // Add to selected subcategory
        if (subcategory && subcategory !== 'none') {
            if (!this.subcategories[subcategory]) {
                this.subcategories[subcategory] = [];
            }
            this.subcategories[subcategory].push(productId);
        }
        
        this.saveSubcategories();
        this.updateProductBadges();
        this.renderSubcategorySections();
    }

    getProductSubcategory(productId) {
        for (const [subcat, ids] of Object.entries(this.subcategories)) {
            if (ids.includes(productId)) {
                return subcat;
            }
        }
        return null;
    }

    setupEventListeners() {
        // Admin panel subcategory selection
        document.addEventListener('change', (e) => {
            if (e.target.id === 'productSubcategory') {
                const productId = parseInt(document.getElementById('productIdForSubcat').value);
                const subcategory = e.target.value;
                
                if (productId && subcategory) {
                    this.assignToSubcategory(productId, subcategory);
                }
            }
        });
    }

    renderSubcategoryFilters() {
        // Add subcategory filter buttons
        const filtersHTML = `
            <div class="subcategory-filters" style="margin: 15px 0;">
                <button class="subcat-filter-btn active" data-subcategory="all">
                    All Products
                </button>
                <button class="subcat-filter-btn" data-subcategory="new_arrival">
                    <i class="fas fa-star"></i> New Arrival
                </button>
                <button class="subcat-filter-btn" data-subcategory="trending">
                    <i class="fas fa-fire"></i> Trending
                </button>
                <button class="subcat-filter-btn" data-subcategory="discount">
                    <i class="fas fa-tag"></i> Discount Offers
                </button>
                <button class="subcat-filter-btn" data-subcategory="featured">
                    <i class="fas fa-crown"></i> Featured
                </button>
            </div>
        `;
        
        const productsSection = document.querySelector('.products-section');
        if (productsSection) {
            productsSection.insertAdjacentHTML('afterbegin', filtersHTML);
            
            // Add event listeners
            document.querySelectorAll('.subcat-filter-btn').forEach(btn => {
                btn.addEventListener('click', () => {
                    document.querySelectorAll('.subcat-filter-btn').forEach(b => 
                        b.classList.remove('active'));
                    btn.classList.add('active');
                    
                    const subcategory = btn.dataset.subcategory;
                    this.filterBySubcategory(subcategory);
                });
            });
        }
    }

    filterBySubcategory(subcategory) {
        if (subcategory === 'all') {
            // Show all products
            if (typeof window.filterProducts === 'function') {
                window.filterProducts();
            }
            return;
        }
        
        const filteredProductIds = this.subcategories[subcategory] || [];
        const filteredProducts = window.allProducts.filter(product => 
            filteredProductIds.includes(product.id)
        );
        
        // Update display
        if (typeof window.displayFilteredProducts === 'function') {
            window.displayFilteredProducts(filteredProducts);
        }
    }

    renderSubcategorySections() {
        // Create sections for each subcategory
        const sections = ['new_arrival', 'trending', 'discount', 'featured'];
        
        sections.forEach(subcat => {
            const products = this.getProductsBySubcategory(subcat);
            if (products.length > 0) {
                this.createSubcategorySection(subcat, products);
            }
        });
    }

    getProductsBySubcategory(subcategory) {
        const productIds = this.subcategories[subcategory] || [];
        return window.allProducts.filter(product => 
            productIds.includes(product.id)
        );
    }

    createSubcategorySection(subcategory, products) {
        const sectionId = `${subcategory}-section`;
        let existingSection = document.getElementById(sectionId);
        
        if (!existingSection) {
            const sectionTitles = {
                'new_arrival': '🌟 New Arrivals',
                'trending': '🔥 Trending Now',
                'discount': '🏷️ Discount Offers',
                'featured': '👑 Featured Products'
            };
            
            const sectionHTML = `
                <section class="subcategory-section" id="${sectionId}">
                    <div class="container">
                        <div class="section-header">
                            <h2>${sectionTitles[subcategory] || subcategory}</h2>
                            <a href="#" class="view-all" data-subcategory="${subcategory}">
                                View All <i class="fas fa-arrow-right"></i>
                            </a>
                        </div>
                        <div class="products-grid" id="${subcategory}-products">
                            ${products.slice(0, 4).map(product => this.createProductCard(product)).join('')}
                        </div>
                    </div>
                </section>
            `;
            
            // Insert before main products section
            const mainSection = document.querySelector('.products-section');
            if (mainSection) {
                mainSection.insertAdjacentHTML('beforebegin', sectionHTML);
            }
        } else {
            // Update existing section
            const container = document.getElementById(`${subcategory}-products`);
            if (container) {
                container.innerHTML = products.slice(0, 4).map(product => 
                    this.createProductCard(product)).join('');
            }
        }
    }

    createProductCard(product) {
        const subcategory = this.getProductSubcategory(product.id);
        const badge = subcategory ? this.getSubcategoryBadge(subcategory) : '';
        
        return `
            <div class="product-card">
                ${badge}
                <img src="${product.image_url || product.image || 'https://via.placeholder.com/500x300'}" 
                     alt="${product.name}" 
                     class="product-image">
                <div class="product-details">
                    <h3 class="product-title">${product.name}</h3>
                    <div class="product-price">₹${product.price}</div>
                    ${product.discount ? `<div class="discount-badge">${product.discount}% OFF</div>` : ''}
                </div>
            </div>
        `;
    }

    getSubcategoryBadge(subcategory) {
        const badges = {
            'new_arrival': '<span class="new-badge">NEW</span>',
            'trending': '<span class="trending-badge">TRENDING</span>',
            'discount': '<span class="discount-badge">SALE</span>',
            'featured': '<span class="featured-badge">FEATURED</span>'
        };
        
        return badges[subcategory] || '';
    }

    updateProductBadges() {
        // Update badges on all product cards
        document.querySelectorAll('.product-card').forEach(card => {
            const productId = parseInt(card.dataset.productId);
            if (productId) {
                const subcategory = this.getProductSubcategory(productId);
                const badgeContainer = card.querySelector('.subcategory-badge');
                
                if (badgeContainer) {
                    badgeContainer.innerHTML = this.getSubcategoryBadge(subcategory);
                }
            }
        });
    }
}

// Initialize subcategory manager
window.subcategoryManager = new SubcategoryManager();

// Add CSS for subcategories
const subcategoryCSS = `
    .subcategory-filters {
        display: flex;
        gap: 10px;
        flex-wrap: wrap;
        margin: 20px 0;
    }
    
    .subcat-filter-btn {
        padding: 8px 16px;
        border: 2px solid #e0e0e0;
        background: white;
        border-radius: 20px;
        cursor: pointer;
        font-weight: 500;
        transition: all 0.3s ease;
        display: flex;
        align-items: center;
        gap: 5px;
    }
    
    .subcat-filter-btn:hover {
        border-color: #8e44ad;
        color: #8e44ad;
    }
    
    .subcat-filter-btn.active {
        background: #8e44ad;
        color: white;
        border-color: #8e44ad;
    }
    
    .subcategory-section {
        margin: 30px 0;
    }
    
    .new-badge {
        position: absolute;
        top: 10px;
        left: 10px;
        background: #2ecc71;
        color: white;
        padding: 3px 10px;
        border-radius: 12px;
        font-size: 11px;
        font-weight: bold;
    }
    
    .trending-badge {
        position: absolute;
        top: 10px;
        left: 10px;
        background: #e74c3c;
        color: white;
        padding: 3px 10px;
        border-radius: 12px;
        font-size: 11px;
        font-weight: bold;
    }
    
    .discount-badge {
        position: absolute;
        top: 10px;
        left: 10px;
        background: #f39c12;
        color: white;
        padding: 3px 10px;
        border-radius: 12px;
        font-size: 11px;
        font-weight: bold;
    }
    
    .featured-badge {
        position: absolute;
        top: 10px;
        left: 10px;
        background: #9b59b6;
        color: white;
        padding: 3px 10px;
        border-radius: 12px;
        font-size: 11px;
        font-weight: bold;
    }
    
    .section-header {
        display: flex;
        justify-content: space-between;
        align-items: center;
        margin-bottom: 20px;
    }
    
    .view-all {
        color: #8e44ad;
        text-decoration: none;
        font-weight: 500;
    }
    
    .view-all:hover {
        text-decoration: underline;
    }
`;

// Add styles to document
if (!document.querySelector('#subcategory-styles')) {
    const style = document.createElement('style');
    style.id = 'subcategory-styles';
    style.textContent = subcategoryCSS;
    document.head.appendChild(style);
}