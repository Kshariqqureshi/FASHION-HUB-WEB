// sync-monitor.js - Monitor data sync
class SyncMonitor {
    constructor() {
        this.statusElement = null;
        this.createStatusPanel();
        this.startMonitoring();
    }
    
    createStatusPanel() {
        const panel = document.createElement('div');
        panel.id = 'sync-monitor';
        panel.style.cssText = `
            position: fixed;
            bottom: 20px;
            right: 20px;
            background: #2c3e50;
            color: white;
            padding: 10px 15px;
            border-radius: 8px;
            font-size: 12px;
            z-index: 9999;
            box-shadow: 0 2px 10px rgba(0,0,0,0.2);
            font-family: monospace;
        `;
        
        panel.innerHTML = `
            <div style="display: flex; align-items: center; gap: 10px;">
                <div id="sync-status-indicator" style="width: 10px; height: 10px; border-radius: 50%; background: #2ecc71;"></div>
                <div>
                    <div>Sync Status: <span id="sync-status-text">Connected</span></div>
                    <div>Products: <span id="product-count">0</span></div>
                    <div>Shops: <span id="shop-count">0</span></div>
                </div>
            </div>
        `;
        
        document.body.appendChild(panel);
        this.statusElement = panel;
    }
    
    startMonitoring() {
        // Update counts every 5 seconds
        setInterval(() => {
            this.updateCounts();
        }, 5000);
        
        // Listen for data updates
        window.addEventListener('storage', (e) => {
            if (e.key === 'fashionHubProducts' || e.key === 'fashionHubShops') {
                this.flashIndicator('#f39c12');
                this.updateCounts();
                setTimeout(() => this.flashIndicator('#2ecc71'), 500);
            }
        });
        
        // Initial update
        this.updateCounts();
    }
    
    updateCounts() {
        const products = localStorage.getItem('fashionHubProducts');
        const shops = localStorage.getItem('fashionHubShops');
        
        const productCount = products ? JSON.parse(products).length : 0;
        const shopCount = shops ? JSON.parse(shops).length : 0;
        
        document.getElementById('product-count').textContent = productCount;
        document.getElementById('shop-count').textContent = shopCount;
    }
    
    flashIndicator(color) {
        const indicator = document.getElementById('sync-status-indicator');
        const originalColor = indicator.style.backgroundColor;
        indicator.style.backgroundColor = color;
        
        setTimeout(() => {
            indicator.style.backgroundColor = originalColor;
        }, 1000);
    }
}

// Start monitor on admin page
if (window.location.pathname.includes('admin')) {
    document.addEventListener('DOMContentLoaded', () => {
        window.syncMonitor = new SyncMonitor();
    });
}