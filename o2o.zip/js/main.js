// Main JavaScript for Fashion Hub Website
document.addEventListener('DOMContentLoaded', function() {
    console.log("🚀 Fashion Hub Website Loaded");
    
    // Initialize everything
    initializeAll();
});

// ===== GLOBAL VARIABLES =====
let userLocation = null;
let userFavorites = [];

// ===== INITIALIZE ALL =====
function initializeAll() {
    console.log("🔧 Initializing everything...");
    
    // Load user favorites
    loadFavorites();
    
    // Initialize navigation
    initializeNavigation();
    
    // Initialize user authentication
    initializeAuth();
    
    // Setup location
    setupLocation();
    
    // Load products
    loadProducts();
    
    // Setup event listeners
    setupEventListeners();
    
    // Setup category filtering
    setupCategoryFiltering();
    
    // Setup data sync
    setupDataSync();
}


// ===== AUTHENTICATION FUNCTIONS =====
function initializeAuth() {
    console.log("🔐 Initializing authentication...");
    updateNavUserActions();
}

function showLoginModal() {
    const loginModal = document.getElementById('loginModal');
    if (loginModal) {
        loginModal.style.display = 'flex';
    }
}

function viewProfile() {
    const user = JSON.parse(localStorage.getItem('currentUser'));
    if (user) {
        alert(`👤 Profile Information:\n\nName: ${user.name}\nMobile: ${user.mobile}\nLocation: ${user.location}\nMember since: ${user.registeredAt ? new Date(user.registeredAt).toLocaleDateString() : 'N/A'}`);
    } else {
        alert('Please login to view your profile.');
        showLoginModal();
    }
}

function logoutUser() {
    if (confirm('Are you sure you want to logout?')) {
        localStorage.removeItem('currentUser');
        updateNavUserActions();
        showNotification('Logged out successfully!', 'success');
    }
}
// ===== SIMPLE LOGOUT SYSTEM =====
document.addEventListener('DOMContentLoaded', function() {
    console.log("🚀 Fashion Hub Loaded");
    initializeSimple();
});

function initializeSimple() {
    loadProducts();
    updateUserInterface();
    setupSimpleEvents();
}

// ===== UPDATE USER INTERFACE =====
function updateUserInterface() {
    const navUserActions = document.getElementById('navUserActions');
    if (!navUserActions) return;
    
    // Check if user exists
    const userData = localStorage.getItem('currentUser');
    let user = null;
    
    if (userData && userData !== 'undefined' && userData !== 'null') {
        try {
            user = JSON.parse(userData);
        } catch(e) {
            localStorage.removeItem('currentUser');
            user = null;
        }
    }
    
    // Clear nav
    navUserActions.innerHTML = '';
    
    if (user && user.name) {
        // User is logged in - Show logout button
        console.log("✅ User logged in:", user.name);
        
        const userDiv = document.createElement('div');
        userDiv.style.cssText = 'display: flex; align-items: center; gap: 10px;';
        
        // Username
        const nameSpan = document.createElement('span');
        nameSpan.style.cssText = 'color: white; background: rgba(255,255,255,0.1); padding: 8px 15px; border-radius: 20px;';
        nameSpan.innerHTML = `<i class="fas fa-user"></i> ${user.name.split(' ')[0]}`;
        
        // Logout button
        const logoutBtn = document.createElement('button');
        logoutBtn.style.cssText = 'background: #e74c3c; color: white; border: none; padding: 8px 15px; border-radius: 20px; cursor: pointer; font-weight: bold;';
        logoutBtn.innerHTML = '<i class="fas fa-sign-out-alt"></i> Logout';
        logoutBtn.onclick = function() {
            simpleLogout();
        };
        
        userDiv.appendChild(nameSpan);
        userDiv.appendChild(logoutBtn);
        navUserActions.appendChild(userDiv);
    } else {
        // No user - Show login button
        console.log("❌ No user logged in");
        
        const loginBtn = document.createElement('div');
        loginBtn.style.cssText = 'color: white; background: rgba(255,255,255,0.1); padding: 8px 15px; border-radius: 20px; cursor: pointer;';
        loginBtn.innerHTML = '<i class="fas fa-user"></i> Login / Register';
        loginBtn.onclick = function() {
            document.getElementById('loginModal').style.display = 'flex';
        };
        
        navUserActions.appendChild(loginBtn);
    }
}

// ===== SIMPLE LOGOUT =====
function simpleLogout() {
    console.log("🔓 Logging out...");
    
    // 1. Remove user from localStorage
    localStorage.removeItem('currentUser');
    
    // 2. Clear favorites
    localStorage.removeItem('fashionHubFavorites');
    
    // 3. Update UI immediately
    updateUserInterface();
    
    // 4. Show message
    alert('✅ Logged out successfully!');
    
    console.log("✅ Logout complete");
}

// ===== LOGIN FUNCTION =====
function simpleLogin() {
    const mobile = document.getElementById('loginMobile').value;
    const password = document.getElementById('loginPassword').value;
    
    if (!mobile || !password) {
        alert('Please enter mobile and password');
        return;
    }
    
    // Get users
    const users = JSON.parse(localStorage.getItem('fashionHubUsers') || '[]');
    
    // For demo, if no users, create one
    if (users.length === 0) {
        const demoUser = {
            id: 1,
            name: 'Demo User',
            mobile: '1234567890',
            password: 'password',
            location: 'Bareilly'
        };
        users.push(demoUser);
        localStorage.setItem('fashionHubUsers', JSON.stringify(users));
    }
    
    // Find user
    const user = users.find(u => u.mobile === mobile && u.password === password);
    
    if (user) {
        // Login
        localStorage.setItem('currentUser', JSON.stringify(user));
        document.getElementById('loginModal').style.display = 'none';
        updateUserInterface();
        alert(`Welcome ${user.name}!`);
    } else {
        alert('Invalid credentials. Try: 1234567890 / password');
    }
}

// ===== REGISTER FUNCTION =====
function simpleRegister() {
    const name = document.getElementById('registerName').value;
    const mobile = document.getElementById('registerMobile').value;
    const password = document.getElementById('registerPassword').value;
    const location = document.getElementById('registerLocation').value;
    
    if (!name || !mobile || !password || !location) {
        alert('Please fill all fields');
        return;
    }
    
    // Get users
    const users = JSON.parse(localStorage.getItem('fashionHubUsers') || '[]');
    
    // Check if exists
    if (users.find(u => u.mobile === mobile)) {
        alert('User already exists');
        return;
    }
    
    // Create user
    const newUser = {
        id: Date.now(),
        name: name,
        mobile: mobile,
        password: password,
        location: location
    };
    
    users.push(newUser);
    localStorage.setItem('fashionHubUsers', JSON.stringify(users));
    
    // Auto login
    localStorage.setItem('currentUser', JSON.stringify(newUser));
    document.getElementById('registerModal').style.display = 'none';
    updateUserInterface();
    
    alert(`Welcome ${name}! Registration successful.`);
}

// ===== LOAD PRODUCTS =====
function loadProducts() {
    const container = document.getElementById('productsContainer');
    if (!container) return;
    
    // Get products
    let products = [];
    const data = localStorage.getItem('fashionHubProducts');
    if (data) {
        try {
            products = JSON.parse(data);
        } catch(e) {}
    }
    
    if (products.length === 0) {
        container.innerHTML = '<div style="text-align:center;padding:40px;">No products. Add sample data.</div>';
        return;
    }
    
    let html = '';
    products.forEach(p => {
        html += `
            <div style="border:1px solid #ddd;padding:10px;border-radius:5px;">
                <h4>${p.name}</h4>
                <p>₹${p.price}</p>
            </div>
        `;
    });
    
    container.innerHTML = html;
}

// ===== SETUP EVENTS =====
function setupSimpleEvents() {
    // Login form
    document.getElementById('loginForm')?.addEventListener('submit', function(e) {
        e.preventDefault();
        simpleLogin();
    });
    
    // Register form
    document.getElementById('registerForm')?.addEventListener('submit', function(e) {
        e.preventDefault();
        simpleRegister();
    });
    
    // Switch forms
    document.getElementById('switchToRegister')?.addEventListener('click', function(e) {
        e.preventDefault();
        document.getElementById('loginModal').style.display = 'none';
        document.getElementById('registerModal').style.display = 'flex';
    });
    
    document.getElementById('switchToLogin')?.addEventListener('click', function(e) {
        e.preventDefault();
        document.getElementById('registerModal').style.display = 'none';
        document.getElementById('loginModal').style.display = 'flex';
    });
    
    // Close modals
    document.getElementById('closeLogin')?.addEventListener('click', function() {
        document.getElementById('loginModal').style.display = 'none';
    });
    
    document.getElementById('closeRegister')?.addEventListener('click', function() {
        document.getElementById('registerModal').style.display = 'none';
    });
}

// ===== MAKE FUNCTIONS GLOBAL =====
window.simpleLogout = simpleLogout;


// ===== FAVORITES SYSTEM =====
function loadFavorites() {
    const savedFavorites = localStorage.getItem('fashionHubFavorites');
    if (savedFavorites) {
        try {
            userFavorites = JSON.parse(savedFavorites);
            console.log(`⭐ Loaded ${userFavorites.length} favorites`);
        } catch(e) {
            console.error("Error parsing favorites:", e);
            userFavorites = [];
        }
    }
}

function toggleFavorite(productId) {
    const index = userFavorites.indexOf(productId);
    
    if (index === -1) {
        // Add to favorites
        userFavorites.push(productId);
        console.log(`⭐ Added product ${productId} to favorites`);
        
        // Show notification
        showNotification('Added to favorites!', 'success');
    } else {
        // Remove from favorites
        userFavorites.splice(index, 1);
        console.log(`❌ Removed product ${productId} from favorites`);
        
        // Show notification
        showNotification('Removed from favorites', 'info');
    }
    
    // Save to localStorage
    localStorage.setItem('fashionHubFavorites', JSON.stringify(userFavorites));
    
    // Update favorite buttons
    updateFavoriteButtons();
    
    return index === -1; // Returns true if added, false if removed
}

function updateFavoriteButtons() {
    document.querySelectorAll('.favorite-btn').forEach(btn => {
        const productId = parseInt(btn.dataset.productId);
        if (userFavorites.includes(productId)) {
            btn.classList.add('active');
            btn.innerHTML = '<i class="fas fa-heart"></i>';
            btn.title = 'Remove from favorites';
        } else {
            btn.classList.remove('active');
            btn.innerHTML = '<i class="far fa-heart"></i>';
            btn.title = 'Add to favorites';
        }
    });
}


function showFavoritesModal() {
    // Get all products
    const products = JSON.parse(localStorage.getItem('fashionHubProducts') || '[]');
    const shops = JSON.parse(localStorage.getItem('fashionHubShops') || '[]');
    
    // Filter favorite products
    const favoriteProducts = products.filter(p => userFavorites.includes(p.id));
    
    // Create modal HTML
    let html = `
        <div class="modal-content favorites-modal">
            <div class="favorites-header">
                <h2><i class="fas fa-heart"></i> My Favorites</h2>
                <span class="favorites-count">${favoriteProducts.length} items</span>
            </div>
            
            <div class="favorites-container">
    `;
    
    if (favoriteProducts.length === 0) {
        html += `
            <div class="empty-favorites">
                <i class="far fa-heart"></i>
                <h3>No favorites yet</h3>
                <p>Click the heart icon on products to add them to favorites</p>
                <button class="btn-chat" onclick="document.getElementById('favoritesModal').style.display='none'" style="background: #8e44ad; color: white; border: none; padding: 10px 20px; border-radius: 6px; cursor: pointer; margin-top: 10px;">
                    <i class="fas fa-shopping-bag"></i> Browse Products
                </button>
            </div>
        `;
    } else {
        html += '<div class="favorites-grid">';
        
        favoriteProducts.forEach(product => {
            const shop = shops.find(s => s.id == product.shop_id) || product;
            const imageUrl = product.image_url || product.image || 'https://via.placeholder.com/300x120/8e44ad/ffffff?text=PRODUCT';
            
            html += `
                <div class="favorite-item">
                    <img src="${imageUrl}" alt="${product.name}" class="favorite-item-image">
                    <div class="favorite-item-info">
                        <div class="favorite-item-name">${product.name}</div>
                        <div class="favorite-item-actions">
                            <button class="favorite-item-chat" onclick="chatOnWhatsApp('${shop.whatsapp || shop.phone || ''}', '${product.name}')">
                                <i class="fab fa-whatsapp"></i> Chat
                            </button>
                            <button class="favorite-item-remove" onclick="removeFromFavorites(${product.id})" title="Remove from favorites">
                                <i class="fas fa-times"></i>
                            </button>
                        </div>
                    </div>
                </div>
            `;
        });
        
        html += '</div>';
    }
    
    html += `
            </div>
            <div style="padding: 15px; border-top: 1px solid #eee; text-align: center;">
                <button class="btn-chat" onclick="document.getElementById('favoritesModal').style.display='none'" style="background: #666; color: white; border: none; padding: 8px 20px; border-radius: 6px; cursor: pointer;">
                    Close
                </button>
            </div>
        </div>
    `;

    
    // Remove existing modal if any
    const existingModal = document.getElementById('favoritesModal');
    if (existingModal) existingModal.remove();
    
    // Create and show modal
    const modal = document.createElement('div');
    modal.className = 'modal';
    modal.id = 'favoritesModal';
    modal.innerHTML = html;
    document.body.appendChild(modal);
    
    // Show modal
    modal.style.display = 'flex';
    
    // Setup close functionality
    modal.addEventListener('click', (e) => {
        if (e.target === modal) {
            modal.style.display = 'none';
            modal.remove();
        }
    });
}




// ===== UPDATED LOCATION FUNCTIONS =====
function showLocationAccess() {
    const accessSection = document.getElementById('locationAccessSection');
    const statusSection = document.getElementById('locationStatus');
    const navLocation = document.querySelector('.nav-location');
    
    if (accessSection) accessSection.style.display = 'block';
    if (statusSection) {
        statusSection.style.display = 'none';
        statusSection.classList.remove('active');
    }
    if (navLocation) {
        navLocation.classList.remove('active');
        navLocation.innerHTML = '<i class="fas fa-map-marker-alt"></i> <span id="navCurrentLocation">Access Location</span>';
    }
}

function showLocationAccessed() {
    const accessSection = document.getElementById('locationAccessSection');
    const statusSection = document.getElementById('locationStatus');
    const locationMessage = document.getElementById('locationMessage');
    const navLocation = document.querySelector('.nav-location');
    
    if (accessSection) accessSection.style.display = 'none';
    if (statusSection) {
        statusSection.style.display = 'flex';
        statusSection.classList.add('active');
    }
    if (locationMessage) locationMessage.style.display = 'block';
    if (navLocation) {
        navLocation.classList.add('active');
        navLocation.innerHTML = '<i class="fas fa-check-circle"></i> <span id="navCurrentLocation">Location On</span>';
    }
    
    // Update distance slider based on saved location
    const savedDistance = localStorage.getItem('preferredDistance') || '2';
    const distanceSlider = document.getElementById('distanceSlider');
    const distanceValue = document.getElementById('distanceValue');
    
    if (distanceSlider && distanceValue) {
        distanceSlider.value = savedDistance;
        distanceValue.textContent = `Within ${savedDistance} km`;
    }
}

function updateLocation() {
    if (confirm('Do you want to update your location?')) {
        // Clear old location
        localStorage.removeItem('userLocation');
        localStorage.removeItem('userLocationTimestamp');
        userLocation = null;
        showLocationAccess();
        requestLocationAccess();
    }
}

// Update setupLocation function to handle status better
function setupLocation() {
    console.log("📍 Setting up location...");
    
    // Check if location was previously accessed
    const savedLocation = localStorage.getItem('userLocation');
    const locationTimestamp = localStorage.getItem('userLocationTimestamp');
    
    if (savedLocation && locationTimestamp) {
        // Check if location is still valid (less than 1 hour old)
        const now = Date.now();
        const locationTime = parseInt(locationTimestamp);
        const hoursDiff = (now - locationTime) / (1000 * 60 * 60);
        
        if (hoursDiff < 1) {
            // Location is still valid
            try {
                userLocation = JSON.parse(savedLocation);
                showLocationAccessed();
                console.log("📍 Using saved location");
            } catch(e) {
                console.error("Error parsing saved location:", e);
                showLocationAccess();
            }
        } else {
            // Location expired
            localStorage.removeItem('userLocation');
            localStorage.removeItem('userLocationTimestamp');
            showLocationAccess();
        }
    } else {
        // No location saved
        showLocationAccess();
    }
}

// Update the displayProducts function to make it more compact
function displayProducts(products, shops, container) {
    if (products.length === 0) {
        container.innerHTML = `
            <div class="no-products">
                <div style="font-size: 64px; color: #ddd; margin-bottom: 20px;">
                    <i class="fas fa-tshirt"></i>
                </div>
                <h3 style="color: #666; margin-bottom: 10px;">No products available yet</h3>
                <p style="color: #888; margin-bottom: 20px;">Products will appear here once added from the admin panel.</p>
                <a href="admin.html" style="display: inline-block; background: #8e44ad; color: white; padding: 12px 24px; border-radius: 6px; text-decoration: none; font-weight: 600; margin-bottom: 10px;">
                    <i class="fas fa-user-shield"></i> Go to Admin Panel
                </a>
            </div>
        `;
        return;
    }
    
    // Build products HTML
    let html = '';
    
    products.forEach(product => {
        // Find shop details
        const shop = shops.find(s => s.id == product.shop_id) || product;
        
        // Get image URL
        let imageUrl = product.image_url || product.image;
        if (!imageUrl || imageUrl === 'undefined') {
            // Use a placeholder or random fashion image
            const fallbackImages = [
                "https://images.unsplash.com/photo-1596755094514-f87e34085b2c?ixlib=rb-4.0.3&auto=format&fit=crop&w=300&h=130&q=80",
                "https://images.unsplash.com/photo-1621072156002-e2fccdc0b176?ixlib=rb-4.0.3&auto=format&fit=crop&w=300&h=130&q=80",
                "https://images.unsplash.com/photo-1542272604-787c3835535d?ixlib=rb-4.0.3&auto=format&fit=crop&w=300&h=130&q=80",
                "https://images.unsplash.com/photo-1582418702059-97ebafb35d09?ixlib=rb-4.0.3&auto=format&fit=crop&w=300&h=130&q=80"
            ];
            const randomIndex = Math.floor(Math.random() * fallbackImages.length);
            imageUrl = fallbackImages[randomIndex];
        }
        
        // Format data
        const price = product.price ? `₹${product.price}` : 'Price on request';
        const category = product.category || 'General';
        const categoryMap = {
            'men': "Men's Fashion",
            'women': "Women's Fashion",
            'footwear': "Footwear",
            'kids': "Kids Wear",
            'accessories': "Accessories"
        };
        const categoryText = categoryMap[category] || category;
        
        // Check if product is in favorites
        const isFavorite = userFavorites.includes(product.id);
        
        // Create compact product card
        html += `
            <div class="product-card" data-product-id="${product.id}">
                <button class="favorite-btn ${isFavorite ? 'active' : ''}" 
                        data-product-id="${product.id}" 
                        onclick="toggleFavorite(${product.id})"
                        title="${isFavorite ? 'Remove from favorites' : 'Add to favorites'}">
                    <i class="${isFavorite ? 'fas' : 'far'} fa-heart"></i>
                </button>
                
                <div class="product-badge">${categoryText}</div>
                <div class="product-image-container">
                    <img src="${imageUrl}" alt="${product.name}" class="product-image" 
                         onerror="this.src='https://via.placeholder.com/300x130/8e44ad/ffffff?text=FASHION'">
                </div>
                
                <div class="product-info">
                    <h3 class="product-title">${product.name || 'Product Name'}</h3>
                    <div class="product-price">${price}</div>
                    <div class="product-actions">
                        <button class="btn-chat" onclick="chatOnWhatsApp('${shop.whatsapp || shop.phone || ''}', '${product.name}')">
                            <i class="fab fa-whatsapp"></i> Chat
                        </button>
                    </div>
                </div>
            </div>
        `;
    });
    
    container.innerHTML = html;
}
// ===== LOCATION SYSTEM =====
function setupLocation() {
    console.log("📍 Setting up location...");
    
    // Check if location was previously accessed
    const savedLocation = localStorage.getItem('userLocation');
    const locationTimestamp = localStorage.getItem('userLocationTimestamp');
    
    if (savedLocation && locationTimestamp) {
        // Check if location is still valid (less than 1 hour old)
        const now = Date.now();
        const locationTime = parseInt(locationTimestamp);
        const hoursDiff = (now - locationTime) / (1000 * 60 * 60);
        
        if (hoursDiff < 1) {
            // Location is still valid
            try {
                userLocation = JSON.parse(savedLocation);
                showLocationAccessed();
                console.log("📍 Using saved location");
            } catch(e) {
                console.error("Error parsing saved location:", e);
                showLocationAccess();
            }
        } else {
            // Location expired
            localStorage.removeItem('userLocation');
            localStorage.removeItem('userLocationTimestamp');
            showLocationAccess();
        }
    } else {
        // No location saved
        showLocationAccess();
    }
}

function showLocationAccess() {
    const accessSection = document.getElementById('locationAccessSection');
    const statusSection = document.getElementById('locationStatus');
    
    if (accessSection) accessSection.style.display = 'block';
    if (statusSection) statusSection.style.display = 'none';
}

function showLocationAccessed() {
    const accessSection = document.getElementById('locationAccessSection');
    const statusSection = document.getElementById('locationStatus');
    const locationMessage = document.getElementById('locationMessage');
    
    if (accessSection) accessSection.style.display = 'none';
    if (statusSection) statusSection.style.display = 'flex';
    if (locationMessage) locationMessage.style.display = 'block';
    
    // Update distance slider based on saved location
    const savedDistance = localStorage.getItem('preferredDistance') || '2';
    const distanceSlider = document.getElementById('distanceSlider');
    const distanceValue = document.getElementById('distanceValue');
    
    if (distanceSlider && distanceValue) {
        distanceSlider.value = savedDistance;
        distanceValue.textContent = `Within ${savedDistance} km`;
    }
}

function requestLocationAccess() {
    if (!navigator.geolocation) {
        alert("Geolocation is not supported by your browser.");
        return;
    }
    
    // Show loading
    const accessBtn = document.getElementById('accessLocationBtn');
    const originalText = accessBtn.innerHTML;
    accessBtn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Getting Location...';
    accessBtn.disabled = true;
    
    navigator.geolocation.getCurrentPosition(
        function(position) {
            // Success
            userLocation = {
                lat: position.coords.latitude,
                lng: position.coords.longitude,
                accuracy: position.coords.accuracy,
                timestamp: position.timestamp
            };
            
            // Save to localStorage with timestamp
            localStorage.setItem('userLocation', JSON.stringify(userLocation));
            localStorage.setItem('userLocationTimestamp', Date.now().toString());
            
            // Show success
            showLocationAccessed();
            
            // Reset button
            accessBtn.innerHTML = originalText;
            accessBtn.disabled = false;
            
            // Show success message
            showNotification('Location accessed successfully!', 'success');
            
            // Filter products by location
            filterByDistance();
        },
        function(error) {
            // Error
            console.error("Geolocation error:", error);
            
            // Reset button
            accessBtn.innerHTML = originalText;
            accessBtn.disabled = false;
            
            // Show error message based on error code
            let errorMessage = "Unable to access location. ";
            switch(error.code) {
                case error.PERMISSION_DENIED:
                    errorMessage += "Please allow location access in your browser settings.";
                    break;
                case error.POSITION_UNAVAILABLE:
                    errorMessage += "Location information is unavailable.";
                    break;
                case error.TIMEOUT:
                    errorMessage += "Location request timed out.";
                    break;
                default:
                    errorMessage += "Please enable location services.";
            }
            
            alert(errorMessage);
        },
        {
            enableHighAccuracy: true,
            timeout: 10000,
            maximumAge: 0
        }
    );
}

function updateLocation() {
    // Clear old location and request new one
    localStorage.removeItem('userLocation');
    localStorage.removeItem('userLocationTimestamp');
    userLocation = null;
    showLocationAccess();
    requestLocationAccess();
}

// ===== FILTER SYSTEM =====
function setupEventListeners() {
    console.log("🔧 Setting up event listeners...");
    
    // Search functionality
    const searchInput = document.getElementById('searchInput') || document.getElementById('navSearchInput');
    if (searchInput) {
        searchInput.addEventListener('input', function(e) {
            filterProductsBySearch(e.target.value);
        });
    }
    
    // Location access
    const accessLocationBtn = document.getElementById('accessLocationBtn');
    if (accessLocationBtn) {
        accessLocationBtn.addEventListener('click', requestLocationAccess);
    }
    
    const navLocationAccess = document.getElementById('navLocationAccess');
    if (navLocationAccess) {
        navLocationAccess.addEventListener('click', requestLocationAccess);
    }
    
    // Distance slider
    const distanceSlider = document.getElementById('distanceSlider');
    if (distanceSlider) {
        distanceSlider.addEventListener('input', function() {
            const value = this.value;
            const distanceValue = document.getElementById('distanceValue');
            if (distanceValue) {
                distanceValue.textContent = `Within ${value} km`;
            }
            localStorage.setItem('preferredDistance', value);
            filterByDistance(value);
        });
    }
    
    // Price range checkboxes
    const priceCheckboxes = document.querySelectorAll('input[name="price"]');
    priceCheckboxes.forEach(checkbox => {
        checkbox.addEventListener('change', function() {
            filterProductsByPrice();
        });
    });
    
    // Shop type checkboxes
    const shopTypeCheckboxes = document.querySelectorAll('input[name="shopType"]');
    shopTypeCheckboxes.forEach(checkbox => {
        checkbox.addEventListener('change', function() {
            filterProductsByShopType();
        });
    });
    
    // Location checkboxes
    const locationCheckboxes = document.querySelectorAll('input[name="location"]');
    locationCheckboxes.forEach(checkbox => {
        checkbox.addEventListener('change', function() {
            filterProductsByLocation();
        });
    });
    
    // Setup modals
    setupModalEvents();
}

function filterByDistance(distance = null) {
    const distanceValue = distance || document.getElementById('distanceSlider')?.value || 2;
    const products = document.querySelectorAll('.product-card');
    
    if (!userLocation) {
        // No location available, show all products
        products.forEach(product => product.style.display = 'flex');
        return;
    }
    
    // In a real app, you would calculate actual distances
    // For demo, we'll simulate distance-based filtering
    products.forEach(product => {
        // Random distance for demo (0.5 to 5 km)
        const randomDistance = 0.5 + Math.random() * 4.5;
        
        if (randomDistance <= parseFloat(distanceValue)) {
            product.style.display = 'flex';
        } else {
            product.style.display = 'none';
        }
    });
    
    // Update location message
    const locationMessage = document.getElementById('locationMessage');
    if (locationMessage) {
        locationMessage.innerHTML = `
            <i class="fas fa-info-circle" style="color: #8e44ad; margin-right: 8px;"></i>
            <span>Showing shops within <strong>${distanceValue} km</strong> of your location. 
            <a href="#" onclick="updateLocation()" style="color: #8e44ad; text-decoration: underline;">Update location</a></span>
        `;
        locationMessage.style.display = 'block';
    }
}

function filterProductsByPrice() {
    const checkedPriceRanges = Array.from(document.querySelectorAll('input[name="price"]:checked'))
        .map(cb => cb.value);
    
    if (checkedPriceRanges.length === 0) {
        // Show all products if no price filter selected
        document.querySelectorAll('.product-card').forEach(product => {
            product.style.display = 'flex';
        });
        return;
    }
    
    document.querySelectorAll('.product-card').forEach(product => {
        const priceElement = product.querySelector('.product-price');
        if (!priceElement) return;
        
        const priceText = priceElement.textContent;
        const priceMatch = priceText.match(/₹(\d+)/);
        if (!priceMatch) return;
        
        const price = parseInt(priceMatch[1]);
        let shouldShow = false;
        
        checkedPriceRanges.forEach(range => {
            if (range === '0-500' && price < 500) shouldShow = true;
            if (range === '500-1000' && price >= 500 && price <= 1000) shouldShow = true;
            if (range === '1000-2000' && price >= 1000 && price <= 2000) shouldShow = true;
            if (range === '2000+' && price > 2000) shouldShow = true;
        });
        
        product.style.display = shouldShow ? 'flex' : 'none';
    });
}

function filterProductsByShopType() {
    const checkedShopTypes = Array.from(document.querySelectorAll('input[name="shopType"]:checked'))
        .map(cb => cb.value);
    
    if (checkedShopTypes.length === 0) {
        // Show all products if no shop type filter selected
        document.querySelectorAll('.product-card').forEach(product => {
            product.style.display = 'flex';
        });
        return;
    }
    
    // Note: Shop type data needs to be stored in product data
    // For demo, we'll use a simple approach
    document.querySelectorAll('.product-card').forEach(product => {
        // In real implementation, you would check shop type from product data
        // For now, we'll randomly show/hide for demo
        const shouldShow = Math.random() > 0.3; // 70% chance to show
        product.style.display = shouldShow ? 'flex' : 'none';
    });
}

function filterProductsByLocation() {
    const checkedLocations = Array.from(document.querySelectorAll('input[name="location"]:checked'))
        .map(cb => cb.value);
    
    if (checkedLocations.length === 0 || checkedLocations.includes('all')) {
        // Show all products if no location or "all" is selected
        document.querySelectorAll('.product-card').forEach(product => {
            product.style.display = 'flex';
        });
        return;
    }
    
    document.querySelectorAll('.product-card').forEach(product => {
        const locationElement = product.querySelector('.product-location span');
        if (!locationElement) return;
        
        const locationText = locationElement.textContent.toLowerCase();
        let shouldShow = false;
        
        checkedLocations.forEach(loc => {
            if (locationText.includes(loc.toLowerCase())) {
                shouldShow = true;
            }
        });
        
        product.style.display = shouldShow ? 'flex' : 'none';
    });
}

// ===== PRODUCT LOADING =====
function loadProducts() {
    console.log("📦 Loading products...");
    
    const container = document.getElementById('productsContainer');
    const countElement = document.getElementById('product-count');
    
    if (!container) {
        console.error("❌ Products container not found!");
        return;
    }
    
    // Show loading state
    container.innerHTML = `
        <div class="loading" style="grid-column: 1/-1; text-align: center; padding: 40px;">
            <i class="fas fa-spinner fa-spin"></i>
            <p>Loading products...</p>
        </div>
    `;
    
    // Get products from localStorage
    let products = [];
    let shops = [];
    
    // Try multiple localStorage keys for compatibility
    const productKeys = ['fashionHubProducts', 'websiteProducts'];
    const shopKeys = ['fashionHubShops', 'websiteShops'];
    
    for (const key of productKeys) {
        const data = localStorage.getItem(key);
        if (data) {
            try {
                products = JSON.parse(data);
                console.log(`✅ Loaded ${products.length} products from ${key}`);
                break;
            } catch(e) {
                console.error(`Error parsing ${key}:`, e);
            }
        }
    }
    
    for (const key of shopKeys) {
        const data = localStorage.getItem(key);
        if (data) {
            try {
                shops = JSON.parse(data);
                break;
            } catch(e) {
                console.error(`Error parsing ${key}:`, e);
            }
        }
    }
    
    // Update count
    if (countElement) {
        countElement.textContent = `${products.length} products available`;
    }
    
    // Display products
    displayProducts(products, shops, container);
}

function displayProducts(products, shops, container) {
    if (products.length === 0) {
        container.innerHTML = `
            <div class="no-products">
                <div style="font-size: 64px; color: #ddd; margin-bottom: 20px;">
                    <i class="fas fa-tshirt"></i>
                </div>
                <h3 style="color: #666; margin-bottom: 10px;">No products available yet</h3>
                <p style="color: #888; margin-bottom: 20px;">Products will appear here once added from the admin panel.</p>
                <a href="admin.html" style="display: inline-block; background: #8e44ad; color: white; padding: 12px 24px; border-radius: 6px; text-decoration: none; font-weight: 600; margin-bottom: 10px;">
                    <i class="fas fa-user-shield"></i> Go to Admin Panel
                </a>
            </div>
        `;
        return;
    }
    
    // Build products HTML
    let html = '';
    
    products.forEach(product => {
        // Find shop details
        const shop = shops.find(s => s.id == product.shop_id) || product;
        
        // Get image URL
        let imageUrl = product.image_url || product.image;
        if (!imageUrl || imageUrl === 'undefined') {
            // Use a placeholder or random fashion image
            const fallbackImages = [
                "https://images.unsplash.com/photo-1596755094514-f87e34085b2c?ixlib=rb-4.0.3&auto=format&fit=crop&w=300&q=80",
                "https://images.unsplash.com/photo-1621072156002-e2fccdc0b176?ixlib=rb-4.0.3&auto=format&fit=crop&w=300&q=80",
                "https://images.unsplash.com/photo-1542272604-787c3835535d?ixlib=rb-4.0.3&auto=format&fit=crop&w=300&q=80",
                "https://images.unsplash.com/photo-1582418702059-97ebafb35d09?ixlib=rb-4.0.3&auto=format&fit=crop&w=300&q=80"
            ];
            const randomIndex = Math.floor(Math.random() * fallbackImages.length);
            imageUrl = fallbackImages[randomIndex];
        }
        
        // Format data
        const price = product.price ? `₹${product.price}` : 'Price on request';
        const category = product.category || 'General';
        const categoryMap = {
            'men': "Men's Fashion",
            'women': "Women's Fashion",
            'footwear': "Footwear",
            'kids': "Kids Wear",
            'accessories': "Accessories"
        };
        const categoryText = categoryMap[category] || category;
        
        // Get address and landmark
        const address = shop.address || shop.full_address || 'Address not available';
        const landmark = shop.landmark || 'Landmark not specified';
        
        // Check if product is in favorites
        const isFavorite = userFavorites.includes(product.id);
        
        // Create product card
        html += `
            <div class="product-card" data-product-id="${product.id}">
                <button class="favorite-btn ${isFavorite ? 'active' : ''}" 
                        data-product-id="${product.id}" 
                        onclick="toggleFavorite(${product.id})"
                        title="${isFavorite ? 'Remove from favorites' : 'Add to favorites'}">
                    <i class="${isFavorite ? 'fas' : 'far'} fa-heart"></i>
                </button>
                
                <div class="product-badge">${categoryText}</div>
                <div class="product-image-container">
                    <img src="${imageUrl}" alt="${product.name}" class="product-image" 
                         onerror="this.src='https://via.placeholder.com/300x140/8e44ad/ffffff?text=FASHION+HUB'">
                </div>
                
                <div class="product-info">
                    <h3 class="product-title">${product.name || 'Product Name'}</h3>
                    
                    <div class="product-price">${price}</div>
                    
                    <div class="product-shop">
                        <i class="fas fa-store"></i>
                        <span>${shop.name || product.shop_name || 'Local Fashion Store'}</span>
                    </div>
                    
                    <div class="product-location">
                        <i class="fas fa-map-marker-alt"></i>
                        <span>${shop.location_area || product.location_area || 'Bareilly'}</span>
                    </div>
                    
                    <div class="product-address">
                        <i class="fas fa-map"></i>
                        <span>${address}</span>
                    </div>
                    
                    <div class="product-landmark">
                        <i class="fas fa-landmark"></i>
                        <span>${landmark}</span>
                    </div>
                    
                    <div class="product-actions">
                        <button class="btn-chat" onclick="chatOnWhatsApp('${shop.whatsapp || shop.phone || ''}', '${product.name}')">
                            <i class="fab fa-whatsapp"></i> Chat
                        </button>
                    </div>
                </div>
            </div>
        `;
    });
    
    container.innerHTML = html;
}

// ===== NAVIGATION =====
function initializeNavigation() {
    console.log("🔧 Initializing navigation...");
    
    // Update user actions in nav
    updateNavUserActions();
    
    // Setup nav search
    setupNavSearch();
    
    // Setup nav location
    setupNavLocation();
    
    // Setup categories navigation
    setupCategoriesNavigation();
}

function updateNavUserActions() {
    const navUserActions = document.getElementById('navUserActions');
    if (!navUserActions) return;
    
    // Check if user is logged in
    const currentUser = JSON.parse(localStorage.getItem('currentUser'));
    
    let html = '';
    
    if (currentUser) {
        // User is logged in
        html = `
            <i class="fas fa-user-circle"></i>
            <span>Hi, ${currentUser.name.split(' ')[0]}</span>
            <div class="dropdown-content" style="display: none;">
                <a href="#" onclick="viewProfile()"><i class="fas fa-user-circle"></i> Profile</a>
                <a href="#" onclick="showFavoritesModal()"><i class="fas fa-heart" style="color: #e74c3c;"></i> My Favorites</a>
                <a href="#" onclick="logoutUser()"><i class="fas fa-sign-out-alt"></i> Logout</a>
            </div>
        `;
    } else {
        // User is not logged in
        html = `
            <i class="fas fa-user"></i>
            <span id="navShowLoginModal" style="cursor: pointer;">Login / Register</span>
            <div class="dropdown-content" style="display: none;">
                <a href="#" id="navShowLoginModal2"><i class="fas fa-sign-in-alt"></i> Login</a>
                <a href="#" onclick="showF bnm
                avoritesModal()"><i class="fas fa-heart" style="color: #e74c3c;"></i> My Favorites</a>
            </div>
        `;
    }
    
    navUserActions.innerHTML = html;
    
    // Add dropdown toggle
    navUserActions.addEventListener('click', function(e) {
        if (!e.target.closest('.dropdown-content')) {
            e.stopPropagation();
            const dropdown = this.querySelector('.dropdown-content');
            dropdown.style.display = dropdown.style.display === 'block' ? 'none' : 'block';
        }
    });
    
    // Close dropdown when clicking elsewhere
    document.addEventListener('click', function() {
        const dropdown = navUserActions.querySelector('.dropdown-content');
        if (dropdown) dropdown.style.display = 'none';
    });
    
    // Add login click handlers
    document.getElementById('navShowLoginModal')?.addEventListener('click', showLoginModal);
    document.getElementById('navShowLoginModal2')?.addEventListener('click', showLoginModal);
}

function setupNavSearch() {
    const navSearchInput = document.getElementById('navSearchInput');
    if (navSearchInput) {
        navSearchInput.addEventListener('input', function(e) {
            filterProductsBySearch(e.target.value);
        });
    }
}

function setupNavLocation() {
    const navLocationAccess = document.getElementById('navLocationAccess');
    const navCurrentLocation = document.getElementById('navCurrentLocation');
    
    if (navLocationAccess) {
        navLocationAccess.addEventListener('click', requestLocationAccess);
    }
    
    // Update location text if available
    if (userLocation && navCurrentLocation) {
        navCurrentLocation.innerHTML = '<i class="fas fa-check-circle"></i> Location Accessed';
    }
}

function setupCategoriesNavigation() {
    const categoryLinks = document.querySelectorAll('.categories-list a[data-category]');
    
    categoryLinks.forEach(link => {
        link.addEventListener('click', function(e) {
            e.preventDefault();
            
            // Remove active class from all
            categoryLinks.forEach(l => l.classList.remove('active'));
            // Add active to clicked
            this.classList.add('active');
            
            const category = this.getAttribute('data-category');
            filterProductsByCategory(category);
            
            // Scroll to products
            document.querySelector('.products-section')?.scrollIntoView({
                behavior: 'smooth'
            });
        });
    });
}

// ===== UTILITY FUNCTIONS =====
function showNotification(message, type = 'info') {
    // Create notification element
    const notification = document.createElement('div');
    notification.className = `notification notification-${type}`;
    notification.innerHTML = `
        <div style="display: flex; align-items: center; gap: 10px;">
            <i class="fas fa-${type === 'success' ? 'check-circle' : 'info-circle'}"></i>
            <span>${message}</span>
        </div>
        <button onclick="this.parentElement.remove()" style="background: none; border: none; color: white; cursor: pointer;">
            <i class="fas fa-times"></i>
        </button>
    `;
    
    // Add styles
    notification.style.cssText = `
        position: fixed;
        top: 20px;
        right: 20px;
        background: ${type === 'success' ? '#2ecc71' : type === 'error' ? '#e74c3c' : '#3498db'};
        color: white;
        padding: 12px 20px;
        border-radius: 6px;
        box-shadow: 0 4px 15px rgba(0,0,0,0.2);
        z-index: 9999;
        display: flex;
        align-items: center;
        justify-content: space-between;
        min-width: 300px;
        animation: slideIn 0.3s ease;
    `;
    
    // Add animation
    const style = document.createElement('style');
    style.textContent = `
        @keyframes slideIn {
            from { transform: translateX(100%); opacity: 0; }
            to { transform: translateX(0); opacity: 1; }
        }
    `;
    document.head.appendChild(style);
    
    document.body.appendChild(notification);
    
    // Auto remove after 3 seconds
    setTimeout(() => {
        if (notification.parentNode) {
            notification.remove();
        }
    }, 3000);
}

function setupModalEvents() {
    // Show login modal when login button is clicked
    document.addEventListener('click', function(e) {
        if (e.target && (e.target.id === 'showLoginModal' || e.target.closest('#showLoginModal'))) {
            e.preventDefault();
            showLoginModal();
        }
    });
    
    // Close modals
    document.getElementById('closeLogin')?.addEventListener('click', function() {
        document.getElementById('loginModal').style.display = 'none';
    });
    
    document.getElementById('closeRegister')?.addEventListener('click', function() {
        document.getElementById('registerModal').style.display = 'none';
    });
    
    // Switch between login/register
    document.getElementById('switchToRegister')?.addEventListener('click', function(e) {
        e.preventDefault();
        document.getElementById('loginModal').style.display = 'none';
        document.getElementById('registerModal').style.display = 'flex';
    });
    
    document.getElementById('switchToLogin')?.addEventListener('click', function(e) {
        e.preventDefault();
        document.getElementById('registerModal').style.display = 'none';
        document.getElementById('loginModal').style.display = 'flex';
    });
    
    // Login form
    const loginForm = document.getElementById('loginForm');
    if (loginForm) {
        loginForm.addEventListener('submit', function(e) {
            e.preventDefault();
            handleLogin();
        });
    }
    
    // Register form
    const registerForm = document.getElementById('registerForm');
    if (registerForm) {
        registerForm.addEventListener('submit', function(e) {
            e.preventDefault();
            handleRegistration();
        });
    }
    
    // Close modal when clicking outside
    window.addEventListener('click', function(e) {
        if (e.target.classList.contains('modal')) {
            e.target.style.display = 'none';
        }
    });
}

function handleLogin() {
    const mobile = document.getElementById('loginMobile').value;
    const password = document.getElementById('loginPassword').value;
    
    // Simple validation
    if (!/^\d{10}$/.test(mobile)) {
        alert('Please enter a valid 10-digit mobile number');
        return;
    }
    
    if (password.length < 6) {
        alert('Password must be at least 6 characters');
        return;
    }
    
    // Get users from localStorage
    const users = JSON.parse(localStorage.getItem('fashionHubUsers') || '[]');
    
    // Find user
    const user = users.find(u => u.mobile === mobile && u.password === password);
    
    if (user) {
        // Login successful
        localStorage.setItem('currentUser', JSON.stringify(user));
        alert(`Welcome back, ${user.name}!`);
        
        // Close modal and refresh UI
        document.getElementById('loginModal').style.display = 'none';
        updateNavUserActions();
    } else {
        alert('Invalid mobile number or password. Try registering first.');
    }
}

function handleRegistration() {
    const name = document.getElementById('registerName').value.trim();
    const mobile = document.getElementById('registerMobile').value;
    const password = document.getElementById('registerPassword').value;
    const location = document.getElementById('registerLocation').value.trim();
    
    // Validation
    if (name.length < 3) {
        alert('Name must be at least 3 characters');
        return;
    }
    
    if (!/^\d{10}$/.test(mobile)) {
        alert('Please enter a valid 10-digit mobile number');
        return;
    }
    
    if (password.length < 6) {
        alert('Password must be at least 6 characters');
        return;
    }
    
    if (!location) {
        alert('Please enter your location');
        return;
    }
    
    // Check if user already exists
    const users = JSON.parse(localStorage.getItem('fashionHubUsers') || '[]');
    const existingUser = users.find(u => u.mobile === mobile);
    
    if (existingUser) {
        alert('User with this mobile number already exists. Please login.');
        return;
    }
    
    // Create new user
    const newUser = {
        id: Date.now(),
        name: name,
        mobile: mobile,
        password: password,
        location: location,
        registeredAt: new Date().toISOString()
    };
    
    // Save user
    users.push(newUser);
    localStorage.setItem('fashionHubUsers', JSON.stringify(users));
    
    // Auto login
    localStorage.setItem('currentUser', JSON.stringify(newUser));
    
    alert(`Welcome to Fashion Hub, ${name}! Registration successful.`);
    
    // Close modal and refresh UI
    document.getElementById('registerModal').style.display = 'none';
    updateNavUserActions();
}

function setupCategoryFiltering() {
    const categoryLinks = document.querySelectorAll('.categories a[data-category]');
    
    categoryLinks.forEach(link => {
        link.addEventListener('click', function(e) {
            e.preventDefault();
            
            // Remove active class from all
            categoryLinks.forEach(l => l.classList.remove('active'));
            // Add active to clicked
            this.classList.add('active');
            
            const category = this.getAttribute('data-category');
            filterProductsByCategory(category);
        });
    });
}

function filterProductsByCategory(category) {
    const products = document.querySelectorAll('.product-card');
    
    if (category === 'all') {
        products.forEach(product => {
            product.style.display = 'flex';
        });
        return;
    }
    
    const categoryMap = {
        'men': "Men's Fashion",
        'women': "Women's Fashion",
        'footwear': "Footwear",
        'kids': "Kids Wear",
        'accessories': "Accessories"
    };
    
    const categoryText = categoryMap[category] || category;
    
    products.forEach(product => {
        const badge = product.querySelector('.product-badge');
        if (badge && (badge.textContent === categoryText || 
                     badge.textContent.toLowerCase().includes(category.toLowerCase()))) {
            product.style.display = 'flex';
        } else {
            product.style.display = 'none';
        }
    });
}

function filterProductsBySearch(query) {
    const products = document.querySelectorAll('.product-card');
    
    if (!query.trim()) {
        products.forEach(product => {
            product.style.display = 'flex';
        });
        return;
    }
    
    const searchTerm = query.toLowerCase();
    
    products.forEach(product => {
        const title = product.querySelector('.product-title')?.textContent.toLowerCase() || '';
        const shop = product.querySelector('.product-shop span')?.textContent.toLowerCase() || '';
        const category = product.querySelector('.product-badge')?.textContent.toLowerCase() || '';
        
        if (title.includes(searchTerm) || shop.includes(searchTerm) || category.includes(searchTerm)) {
            product.style.display = 'flex';
        } else {
            product.style.display = 'none';
        }
    });
}

function setupDataSync() {
    // Check for data updates every 2 seconds
    setInterval(checkForUpdates, 2000);
    
    // Also listen for storage events (when admin updates data)
    window.addEventListener('storage', function(e) {
        if (e.key === 'dataUpdated' || 
            e.key === 'fashionHubProducts' || 
            e.key === 'fashionHubShops') {
            console.log("🔄 Data updated, refreshing products...");
            loadProducts();
        }
    });
}

function checkForUpdates() {
    const lastUpdate = localStorage.getItem('lastDataUpdate');
    const currentUpdate = localStorage.getItem('dataUpdated');
    
    if (lastUpdate !== currentUpdate) {
        console.log("🔄 New data detected, updating...");
        localStorage.setItem('lastDataUpdate', currentUpdate);
        loadProducts();
    }
}

// ===== MAKE FUNCTIONS GLOBAL =====
window.toggleFavorite = toggleFavorite;
window.showFavoritesModal = showFavoritesModal;
window.removeFromFavorites = removeFromFavorites;
window.requestLocationAccess = requestLocationAccess;
window.updateLocation = updateLocation;
window.chatOnWhatsApp = chatOnWhatsApp;
window.showLoginModal = showLoginModal;
window.viewProfile = viewProfile;
window.logoutUser = logoutUser;

// WhatsApp function
function chatOnWhatsApp(phoneNumber, productName) {
    if (!phoneNumber || phoneNumber === 'undefined' || phoneNumber === 'null') {
        alert('WhatsApp number not available for this shop');
        return;
    }
    
    const cleanNumber = phoneNumber.toString().replace(/\D/g, '');
    
    if (cleanNumber.length !== 10) {
        alert('Invalid WhatsApp number');
        return;
    }
    
    const message = `Hi, I'm interested in your product: ${productName}. Please share more details.`;
    const encodedMessage = encodeURIComponent(message);
    const whatsappUrl = `https://wa.me/91${cleanNumber}?text=${encodedMessage}`;
    
    window.open(whatsappUrl, '_blank');
}

// Initialize when page loads
if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', initializeAll);
} else {
    initializeAll();
}

