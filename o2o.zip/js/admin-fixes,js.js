// admin-fixes.js - Extra fixes for admin panel
document.addEventListener('DOMContentLoaded', function() {
    // Prevent double submissions
    let formSubmitting = false;
    
    document.querySelectorAll('form').forEach(form => {
        form.addEventListener('submit', function(e) {
            if (formSubmitting) {
                e.preventDefault();
                return;
            }
            
            formSubmitting = true;
            setTimeout(() => {
                formSubmitting = false;
            }, 2000);
        });
    });
    
    // Prevent memory leaks
    window.addEventListener('beforeunload', function() {
        // Clean up event listeners
        document.querySelectorAll('.modal').forEach(modal => {
            modal.classList.remove('active');
        });
    });
    
    // Auto-save every 30 seconds
    setInterval(() => {
        if (document.visibilityState === 'visible') {
            console.log('Auto-saving admin data...');
            localStorage.setItem('adminAutoSave', new Date().toISOString());
        }
    }, 30000);
    
    // Error handling
    window.addEventListener('error', function(e) {
        console.error('Admin Panel Error:', e.error);
        
        // Show user-friendly error
        if (e.error.message.includes('QuotaExceededError')) {
            alert('Storage is full! Please delete some data.');
        }
    });
});