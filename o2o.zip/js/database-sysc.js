// database-sync.js - Sync data between Admin and Website

const API_BASE_URL = window.location.origin.includes('localhost') 
    ? 'http://localhost/fashion-hub/api' 
    : '/api';

// Sync Functions
class DataSync {
    constructor() {
        this.products = [];
        this.shops = [];
    }

    // Load products from API
    async loadProducts() {
        try {
            const response = await fetch(`${API_BASE_URL}/get-products.php`);
            const data = await response.json();
            
            if (data.success) {
                this.products = data.products;
                this.saveToLocalStorage('fashionHubProducts', this.products);
                return this.products;
            } else {
                // Fallback to localStorage
                return this.loadFromLocalStorage('fashionHubProducts');
            }
        } catch (error) {
            console.error('Error loading products:', error);
            return this.loadFromLocalStorage('fashionHubProducts');
        }
    }

    // Load shops from API
    async loadShops() {
        try {
            const response = await fetch(`${API_BASE_URL}/get-shops.php`);
            const data = await response.json();
            
            if (data.success) {
                this.shops = data.shops;
                this.saveToLocalStorage('fashionHubShops', this.shops);
                return this.shops;
            } else {
                return this.loadFromLocalStorage('fashionHubShops');
            }
        } catch (error) {
            console.error('Error loading shops:', error);
            return this.loadFromLocalStorage('fashionHubShops');
        }
    }

    // Add new shop
    async addShop(shopData) {
        try {
            const response = await fetch(`${API_BASE_URL}/add-shop.php`, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify(shopData)
            });
            
            const result = await response.json();
            
            if (result.success) {
                // Also save to localStorage for immediate display
                const shops = this.loadFromLocalStorage('fashionHubShops') || [];
                shops.push({ id: result.shop_id, ...shopData });
                this.saveToLocalStorage('fashionHubShops', shops);
                
                return result;
            }
            return result;
        } catch (error) {
            console.error('Error adding shop:', error);
            
            // Fallback: Save to localStorage only
            const shops = this.loadFromLocalStorage('fashionHubShops') || [];
            const newShopId = Date.now();
            shops.push({ id: newShopId, ...shopData });
            this.saveToLocalStorage('fashionHubShops', shops);
            
            return {
                success: true,
                message: 'Shop saved locally (offline mode)',
                shop_id: newShopId
            };
        }
    }

    // Add new product
    async addProduct(productData) {
        try {
            const response = await fetch(`${API_BASE_URL}/add-product.php`, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify(productData)
            });
            
            const result = await response.json();
            
            if (result.success) {
                // Also save to localStorage for immediate display
                const products = this.loadFromLocalStorage('fashionHubProducts') || [];
                products.push({ id: result.product_id, ...productData });
                this.saveToLocalStorage('fashionHubProducts', products);
                
                return result;
            }
            return result;
        } catch (error) {
            console.error('Error adding product:', error);
            
            // Fallback: Save to localStorage only
            const products = this.loadFromLocalStorage('fashionHubProducts') || [];
            const newProductId = Date.now();
            products.push({ id: newProductId, ...productData });
            this.saveToLocalStorage('fashionHubProducts', products);
            
            return {
                success: true,
                message: 'Product saved locally (offline mode)',
                product_id: newProductId
            };
        }
    }

    // Sync all data
    async syncAllData() {
        console.log('Syncing data...');
        
        const [products, shops] = await Promise.all([
            this.loadProducts(),
            this.loadShops()
        ]);
        
        console.log('Sync complete:', {
            products: products.length,
            shops: shops.length
        });
        
        return { products, shops };
    }

    // Helper functions
    saveToLocalStorage(key, data) {
        localStorage.setItem(key, JSON.stringify(data));
    }

    loadFromLocalStorage(key) {
        const data = localStorage.getItem(key);
        return data ? JSON.parse(data) : null;
    }

    // Clear all data
    clearAllData() {
        localStorage.removeItem('fashionHubProducts');
        localStorage.removeItem('fashionHubShops');
        localStorage.removeItem('fashionHubUsers');
        console.log('All data cleared from localStorage');
    }
}

// Create global instance
window.dataSync = new DataSync();