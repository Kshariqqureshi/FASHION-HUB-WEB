// data-sync-fixed.js - GUARANTEED SOLUTION for Admin-Website Sync

class DataSyncManager {
    constructor() {
        this.products = [];
        this.shops = [];
        this.isInitialized = false;
        this.init();
    }

    init() {
        console.log('🚀 DataSyncManager Initializing...');
        this.loadData();
        this.setupListeners();
        this.isInitialized = true;
        console.log('✅ DataSyncManager Ready');
    }

    // 1. LOAD DATA - Priority Order
    loadData() {
        console.log('📥 Loading data...');
        
        // Priority 1: Check ADMIN data first (fashionHubProducts)
        const adminProducts = localStorage.getItem('fashionHubProducts');
        const adminShops = localStorage.getItem('fashionHubShops');
        
        // Priority 2: Check WEBSITE data (websiteProducts)
        const websiteProducts = localStorage.getItem('websiteProducts');
        const websiteShops = localStorage.getItem('websiteShops');
        
        // Priority 3: Sample data as last resort
        
        console.log('Admin Products:', adminProducts ? 'Available' : 'Not found');
        console.log('Website Products:', websiteProducts ? 'Available' : 'Not found');

        // Use ADMIN data if available (Yeh IMPORTANT hai!)
        if (adminProducts) {
            try {
                this.products = JSON.parse(adminProducts);
                console.log(`✅ Loaded ${this.products.length} products from ADMIN`);
                
                // ALSO save to website storage for consistency
                localStorage.setItem('websiteProducts', adminProducts);
            } catch (e) {
                console.error('Error parsing admin products:', e);
            }
        }
        // If no admin data, use website data
        else if (websiteProducts) {
            try {
                this.products = JSON.parse(websiteProducts);
                console.log(`✅ Loaded ${this.products.length} products from WEBSITE`);
            } catch (e) {
                console.error('Error parsing website products:', e);
            }
        }
        // If nothing, load sample data
        else {
            this.loadSampleData();
        }

        // Same for shops
        if (adminShops) {
            try {
                this.shops = JSON.parse(adminShops);
                localStorage.setItem('websiteShops', adminShops);
            } catch (e) {
                console.error('Error parsing admin shops:', e);
            }
        } else if (websiteShops) {
            try {
                this.shops = JSON.parse(websiteShops);
            } catch (e) {
                console.error('Error parsing website shops:', e);
            }
        }

        console.log(`📊 Final Count: ${this.products.length} products, ${this.shops.length} shops`);
        return this.products;
    }

    // 2. SAMPLE DATA (Fallback)
    loadSampleData() {
        console.log('📝 Loading sample data...');
        this.products = [
            {
                id: 1,
                name: "Men's Formal Shirt",
                shop_id: 1,
                shop_name: "Trendy Fashions",
                owner_name: "Rahul Verma",
                location_area: "Civil Lines",
                price: 1299,
                category: "men",
                image_url: "https://images.unsplash.com/photo-1596755094514-f87e34085b2c?ixlib=rb-4.0.3&auto=format&fit=crop&w=500&q=80",
                phone: "9876543210",
                whatsapp: "9876543210",
                distance: 0.8,
                created_at: new Date().toISOString()
            },
            {
                id: 2,
                name: "Women's Silk Saree",
                shop_id: 2,
                shop_name: "Ethnic Wear Hub",
                owner_name: "Priya Sharma",
                location_area: "Rampur Garden",
                price: 2999,
                category: "women",
                image_url: "https://images.unsplash.com/photo-1566878980327-e2d6ad13b75c?ixlib=rb-4.0.3&auto=format&fit=crop&w=500&q=80",
                phone: "9876543211",
                whatsapp: "9876543211",
                distance: 1.5,
                created_at: new Date().toISOString()
            }
        ];
        
        this.shops = [
            {
                id: 1,
                name: "Trendy Fashions",
                owner_name: "Rahul Verma",
                address: "Shop No. 12, Crossroad Mall, Civil Lines, Bareilly",
                location_area: "Civil Lines",
                location_code: "civil",
                distance_km: 0.8,
                phone: "9876543210",
                whatsapp: "9876543210",
                shop_type: "boutique",
                category: "men",
                created_at: new Date().toISOString()
            }
        ];
        
        // Save to localStorage
        localStorage.setItem('websiteProducts', JSON.stringify(this.products));
        localStorage.setItem('websiteShops', JSON.stringify(this.shops));
        
        console.log('✅ Sample data loaded');
    }

    // 3. SETUP REAL-TIME LISTENERS
    setupListeners() {
        console.log('👂 Setting up real-time listeners...');
        
        // Listen for ADMIN data changes
        window.addEventListener('storage', (event) => {
            console.log('🔔 Storage event detected:', event.key);
            
            if (event.key === 'fashionHubProducts') {
                console.log('🔄 ADMIN updated products!');
                this.handleAdminUpdate();
            }
            
            if (event.key === 'fashionHubShops') {
                console.log('🔄 ADMIN updated shops!');
                this.handleAdminUpdate();
            }
            
            if (event.key === 'forceWebsiteUpdate') {
                console.log('🔄 Force update requested!');
                this.handleAdminUpdate();
            }
        });

        // Manual refresh button (agar chahiye to)
        this.addRefreshButton();
        
        // Auto-refresh every 5 seconds
        setInterval(() => {
            this.checkForUpdates();
        }, 5000);
    }

    // 4. HANDLE ADMIN UPDATES
    handleAdminUpdate() {
        console.log('🔄 Processing admin update...');
        
        // Reload data from admin
        const adminProducts = localStorage.getItem('fashionHubProducts');
        const adminShops = localStorage.getItem('fashionHubShops');
        
        if (adminProducts) {
            try {
                this.products = JSON.parse(adminProducts);
                
                // CRITICAL: Also save to website storage
                localStorage.setItem('websiteProducts', adminProducts);
                
                console.log(`✅ Updated ${this.products.length} products from ADMIN`);
                
                // Show notification
                this.showNotification(`${this.products.length} products updated!`);
                
                // Trigger page refresh if function exists
                if (typeof window.refreshProducts === 'function') {
                    window.refreshProducts();
                }
                
                // Auto-reload page after 1 second
                setTimeout(() => {
                    if (confirm('New products added! Refresh page to see them?')) {
                        window.location.reload();
                    }
                }, 1000);
                
            } catch (e) {
                console.error('Error updating from admin:', e);
            }
        }
    }

    // 5. CHECK FOR UPDATES
    checkForUpdates() {
        // Check if admin added new data
        const lastUpdate = localStorage.getItem('lastAdminUpdate');
        if (lastUpdate) {
            const now = Date.now();
            const updateTime = parseInt(lastUpdate);
            
            if (now - updateTime < 10000) { // 10 seconds mein update hua hai
                console.log('🔄 Recent update detected, refreshing...');
                this.loadData();
                
                if (typeof window.filterProducts === 'function') {
                    window.filterProducts();
                }
                
                localStorage.removeItem('lastAdminUpdate');
            }
        }
    }

    // 6. UTILITY FUNCTIONS
    showNotification(message) {
        // Create notification element
        const notification = document.createElement('div');
        notification.id = 'dataSyncNotification';
        notification.innerHTML = `
            <div style="
                position: fixed;
                top: 20px;
                right: 20px;
                background: #2ecc71;
                color: white;
                padding: 15px 20px;
                border-radius: 8px;
                z-index: 99999;
                box-shadow: 0 4px 12px rgba(0,0,0,0.2);
                display: flex;
                align-items: center;
                gap: 10px;
                animation: slideIn 0.3s ease;
            ">
                <i class="fas fa-sync-alt" style="font-size: 18px;"></i>
                <span>${message}</span>
                <button onclick="this.parentElement.remove()" style="
                    background: none;
                    border: none;
                    color: white;
                    cursor: pointer;
                    margin-left: 10px;
                ">×</button>
            </div>
        `;
        
        // Add styles
        const style = document.createElement('style');
        style.textContent = `
            @keyframes slideIn {
                from { transform: translateX(100%); opacity: 0; }
                to { transform: translateX(0); opacity: 1; }
            }
        `;
        document.head.appendChild(style);
        
        // Add to page
        document.body.appendChild(notification);
        
        // Auto-remove after 5 seconds
        setTimeout(() => {
            if (notification.parentElement) {
                notification.remove();
            }
        }, 5000);
    }

    addRefreshButton() {
        // Add refresh button to page
        const refreshBtn = document.createElement('button');
        refreshBtn.id = 'manualRefreshBtn';
        refreshBtn.innerHTML = '<i class="fas fa-sync-alt"></i> Sync Admin Data';
        refreshBtn.style.cssText = `
            position: fixed;
            bottom: 20px;
            right: 20px;
            background: #8e44ad;
            color: white;
            border: none;
            padding: 10px 15px;
            border-radius: 20px;
            cursor: pointer;
            z-index: 1000;
            box-shadow: 0 2px 10px rgba(0,0,0,0.2);
            display: none;
        `;
        
        refreshBtn.onclick = () => {
            this.forceSync();
        };
        
        document.body.appendChild(refreshBtn);
        
        // Show button after 5 seconds
        setTimeout(() => {
            refreshBtn.style.display = 'block';
        }, 5000);
    }

    forceSync() {
        console.log('🔄 Manual sync requested');
        this.loadData();
        this.showNotification('Data synchronized with admin panel!');
        
        if (typeof window.filterProducts === 'function') {
            window.filterProducts();
        }
    }

    // 7. GETTERS
    getProducts() {
        return this.products;
    }

    getShops() {
        return this.shops;
    }

    getProductCount() {
        return this.products.length;
    }
}

// Initialize globally
window.dataSyncManager = new DataSyncManager();

// Make available to other scripts
window.getSyncedProducts = () => window.dataSyncManager.getProducts();
window.refreshProducts = () => {
    window.dataSyncManager.loadData();
    if (typeof filterProducts === 'function') {
        filterProducts();
    }
};

// Auto-initialize
document.addEventListener('DOMContentLoaded', () => {
    console.log('📱 Page loaded, syncing data...');
    window.dataSyncManager.loadData();
});