// image-gallery.js - Multi-Image Gallery with Scroll

class ImageGallery {
    constructor() {
        this.currentGalleries = new Map();
        this.init();
    }

    init() {
        this.setupEventListeners();
        this.setupFullscreenGallery();
    }

    // Create gallery HTML for product
    createGalleryHTML(product) {
        const images = this.getProductImages(product);
        const imageCount = images.length;
        
        if (imageCount <= 1) {
            // Single image - simple display
            return `
                <div class="product-image-gallery">
                    <img src="${images[0]}" 
                         alt="${product.name}" 
                         class="product-main-image"
                         loading="lazy">
                </div>
            `;
        }
        
        // Multiple images - gallery with navigation
        return `
            <div class="product-image-gallery" data-product-id="${product.id}">
                <img src="${images[0]}" 
                     alt="${product.name}" 
                     class="product-main-image"
                     loading="lazy"
                     data-index="0">
                
                <div class="image-counter">
                    <i class="fas fa-images"></i> 1/${imageCount}
                </div>
                
                <div class="gallery-nav">
                    <button class="nav-arrow prev-arrow" onclick="imageGallery.prevImage(${product.id})" disabled>
                        <i class="fas fa-chevron-left"></i>
                    </button>
                    <button class="nav-arrow next-arrow" onclick="imageGallery.nextImage(${product.id})">
                        <i class="fas fa-chevron-right"></i>
                    </button>
                </div>
                
                <div class="image-thumbnails" id="thumbnails-${product.id}">
                    ${images.map((img, index) => `
                        <div class="thumbnail ${index === 0 ? 'active' : ''}" 
                             onclick="imageGallery.changeImage(${product.id}, ${index})">
                            <img src="${img}" alt="Thumbnail ${index + 1}" loading="lazy">
                        </div>
                    `).join('')}
                </div>
                
                <div class="gallery-actions" style="position: absolute; top: 10px; left: 10px;">
                    <button class="fullscreen-btn" onclick="imageGallery.openFullscreen(${product.id})"
                            style="background: rgba(0,0,0,0.5); color: white; border: none; width: 30px; height: 30px; border-radius: 50%; cursor: pointer;">
                        <i class="fas fa-expand"></i>
                    </button>
                </div>
            </div>
        `;
    }

    // Get product images array
    getProductImages(product) {
        // Check for multiple images
        if (product.images && Array.isArray(product.images) && product.images.length > 0) {
            return product.images;
        }
        
        // Check for image_urls
        if (product.image_urls && Array.isArray(product.image_urls)) {
            return product.image_urls;
        }
        
        // Single image
        const image = product.image_url || product.image || 
                     'https://via.placeholder.com/500x300?text=Product+Image';
        
        return [image];
    }

    // Change image in gallery
    changeImage(productId, index) {
        const gallery = document.querySelector(`[data-product-id="${productId}"]`);
        if (!gallery) return;
        
        const images = this.getProductImages(
            window.allProducts.find(p => p.id === productId) || {}
        );
        
        if (index < 0 || index >= images.length) return;
        
        // Update main image
        const mainImage = gallery.querySelector('.product-main-image');
        mainImage.src = images[index];
        mainImage.dataset.index = index;
        
        // Update counter
        const counter = gallery.querySelector('.image-counter');
        if (counter) {
            counter.innerHTML = `<i class="fas fa-images"></i> ${index + 1}/${images.length}`;
        }
        
        // Update thumbnails
        gallery.querySelectorAll('.thumbnail').forEach((thumb, i) => {
            thumb.classList.toggle('active', i === index);
        });
        
        // Update navigation arrows
        this.updateNavButtons(productId, index, images.length);
        
        // Store current index
        this.currentGalleries.set(productId, index);
        
        // Add animation
        mainImage.style.opacity = '0';
        setTimeout(() => {
            mainImage.style.opacity = '1';
            mainImage.style.transition = 'opacity 0.3s ease';
        }, 10);
    }

    // Next image
    nextImage(productId) {
        const gallery = document.querySelector(`[data-product-id="${productId}"]`);
        if (!gallery) return;
        
        const images = this.getProductImages(
            window.allProducts.find(p => p.id === productId) || {}
        );
        
        const currentIndex = parseInt(gallery.querySelector('.product-main-image').dataset.index) || 0;
        const nextIndex = (currentIndex + 1) % images.length;
        
        this.changeImage(productId, nextIndex);
    }

    // Previous image
    prevImage(productId) {
        const gallery = document.querySelector(`[data-product-id="${productId}"]`);
        if (!gallery) return;
        
        const images = this.getProductImages(
            window.allProducts.find(p => p.id === productId) || {}
        );
        
        const currentIndex = parseInt(gallery.querySelector('.product-main-image').dataset.index) || 0;
        const prevIndex = currentIndex === 0 ? images.length - 1 : currentIndex - 1;
        
        this.changeImage(productId, prevIndex);
    }

    // Update navigation buttons
    updateNavButtons(productId, currentIndex, totalImages) {
        const gallery = document.querySelector(`[data-product-id="${productId}"]`);
        if (!gallery) return;
        
        const prevBtn = gallery.querySelector('.prev-arrow');
        const nextBtn = gallery.querySelector('.next-arrow');
        
        if (prevBtn) {
            prevBtn.disabled = currentIndex === 0;
        }
        
        if (nextBtn) {
            nextBtn.disabled = currentIndex === totalImages - 1;
        }
    }

    // Setup event listeners
    setupEventListeners() {
        // Keyboard navigation
        document.addEventListener('keydown', (e) => {
            const fullscreenModal = document.getElementById('fullscreenGalleryModal');
            if (fullscreenModal && fullscreenModal.style.display === 'flex') {
                if (e.key === 'ArrowLeft') {
                    this.fullscreenPrev();
                } else if (e.key === 'ArrowRight') {
                    this.fullscreenNext();
                } else if (e.key === 'Escape') {
                    this.closeFullscreen();
                }
            }
        });
        
        // Swipe support for mobile
        let touchStartX = 0;
        let touchEndX = 0;
        
        document.addEventListener('touchstart', (e) => {
            touchStartX = e.changedTouches[0].screenX;
        });
        
        document.addEventListener('touchend', (e) => {
            touchEndX = e.changedTouches[0].screenX;
            this.handleSwipe(touchStartX, touchEndX);
        });
    }

    // Handle swipe gestures
    handleSwipe(startX, endX) {
        const diff = startX - endX;
        const threshold = 50;
        
        if (Math.abs(diff) > threshold) {
            const fullscreenModal = document.getElementById('fullscreenGalleryModal');
            if (fullscreenModal && fullscreenModal.style.display === 'flex') {
                if (diff > 0) {
                    this.fullscreenNext(); // Swipe left
                } else {
                    this.fullscreenPrev(); // Swipe right
                }
            }
        }
    }

    // Fullscreen Gallery Functions
    setupFullscreenGallery() {
        // Create fullscreen modal if not exists
        if (!document.getElementById('fullscreenGalleryModal')) {
            const modalHTML = `
                <div class="fullscreen-gallery-modal" id="fullscreenGalleryModal">
                    <button class="fullscreen-close" onclick="imageGallery.closeFullscreen()">
                        <i class="fas fa-times"></i>
                    </button>
                    
                    <div class="fullscreen-gallery">
                        <img id="fullscreenImage" class="fullscreen-image" src="" alt="">
                        
                        <div class="fullscreen-nav">
                            <button class="fullscreen-arrow" onclick="imageGallery.fullscreenPrev()">
                                <i class="fas fa-chevron-left"></i>
                            </button>
                            <button class="fullscreen-arrow" onclick="imageGallery.fullscreenNext()">
                                <i class="fas fa-chevron-right"></i>
                            </button>
                        </div>
                        
                        <div class="fullscreen-counter" id="fullscreenCounter">1/1</div>
                    </div>
                </div>
            `;
            
            document.body.insertAdjacentHTML('beforeend', modalHTML);
        }
    }

    openFullscreen(productId) {
        const product = window.allProducts.find(p => p.id === productId);
        if (!product) return;
        
        const images = this.getProductImages(product);
        const currentIndex = this.currentGalleries.get(productId) || 0;
        
        // Store gallery info
        this.currentFullscreen = {
            productId,
            images,
            currentIndex
        };
        
        // Update fullscreen image
        this.updateFullscreenImage(currentIndex);
        
        // Show modal
        const modal = document.getElementById('fullscreenGalleryModal');
        modal.style.display = 'flex';
        
        // Disable body scroll
        document.body.style.overflow = 'hidden';
    }

    closeFullscreen() {
        const modal = document.getElementById('fullscreenGalleryModal');
        modal.style.display = 'none';
        document.body.style.overflow = 'auto';
    }

    updateFullscreenImage(index) {
        if (!this.currentFullscreen || !this.currentFullscreen.images[index]) return;
        
        const image = this.currentFullscreen.images[index];
        const imgElement = document.getElementById('fullscreenImage');
        const counterElement = document.getElementById('fullscreenCounter');
        
        // Add loading animation
        imgElement.style.opacity = '0';
        
        // Preload image
        const preloadImg = new Image();
        preloadImg.onload = () => {
            imgElement.src = image;
            imgElement.style.opacity = '1';
            imgElement.style.transition = 'opacity 0.3s ease';
        };
        preloadImg.src = image;
        
        // Update counter
        if (counterElement) {
            counterElement.textContent = `${index + 1}/${this.currentFullscreen.images.length}`;
        }
        
        // Update current index
        this.currentFullscreen.currentIndex = index;
    }

    fullscreenNext() {
        if (!this.currentFullscreen) return;
        
        const nextIndex = (this.currentFullscreen.currentIndex + 1) % this.currentFullscreen.images.length;
        this.updateFullscreenImage(nextIndex);
    }

    fullscreenPrev() {
        if (!this.currentFullscreen) return;
        
        const prevIndex = this.currentFullscreen.currentIndex === 0 ? 
            this.currentFullscreen.images.length - 1 : 
            this.currentFullscreen.currentIndex - 1;
        
        this.updateFullscreenImage(prevIndex);
    }

    // Auto-scroll for thumbnails
    setupThumbnailScroll(productId) {
        const thumbnails = document.getElementById(`thumbnails-${productId}`);
        if (!thumbnails) return;
        
        let isDown = false;
        let startX;
        let scrollLeft;
        
        thumbnails.addEventListener('mousedown', (e) => {
            isDown = true;
            thumbnails.classList.add('active');
            startX = e.pageX - thumbnails.offsetLeft;
            scrollLeft = thumbnails.scrollLeft;
        });
        
        thumbnails.addEventListener('mouseleave', () => {
            isDown = false;
            thumbnails.classList.remove('active');
        });
        
        thumbnails.addEventListener('mouseup', () => {
            isDown = false;
            thumbnails.classList.remove('active');
        });
        
        thumbnails.addEventListener('mousemove', (e) => {
            if (!isDown) return;
            e.preventDefault();
            const x = e.pageX - thumbnails.offsetLeft;
            const walk = (x - startX) * 2;
            thumbnails.scrollLeft = scrollLeft - walk;
        });
        
        // Touch support
        thumbnails.addEventListener('touchstart', (e) => {
            startX = e.touches[0].pageX - thumbnails.offsetLeft;
            scrollLeft = thumbnails.scrollLeft;
        });
        
        thumbnails.addEventListener('touchmove', (e) => {
            const x = e.touches[0].pageX - thumbnails.offsetLeft;
            const walk = (x - startX) * 2;
            thumbnails.scrollLeft = scrollLeft - walk;
        });
    }

    // Initialize all galleries on page
    initializeAllGalleries() {
        document.querySelectorAll('[data-product-id]').forEach(gallery => {
            const productId = parseInt(gallery.dataset.productId);
            this.setupThumbnailScroll(productId);
        });
    }
}

// Initialize gallery
window.imageGallery = new ImageGallery();

// Auto-initialize on page load
document.addEventListener('DOMContentLoaded', () => {
    setTimeout(() => {
        window.imageGallery.initializeAllGalleries();
    }, 1000);
});