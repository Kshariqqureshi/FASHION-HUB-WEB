# Fashion Hub - Bareilly's Local Fashion Marketplace
A complete local fashion marketplace web application for Bareilly, Uttar Pradesh with MySQL database integration and admin panel.

🚀 Quick Start
Download all project files
Open index.html in any browser
Click "Add Sample Products" to get started
For admin: Go to login.html → Use:
Username: SHARIQ142
Password: Shariq123@

📁 Project Structure

fashion-hub-project/
├── index.html # Main website
├── admin.html # Admin panel
├── login.html # Admin login page
├── css/ # CSS stylesheets
├── js/ # JavaScript files
├── api/ # Backend API files
├── config/ # Configuration files
├── images/ # Image assets
├── package.json # Node.js dependencies

✨ Key Features

🛍️ For Users
Add products to favorites ❤️
Filter by price, location, shop type
Direct WhatsApp chat with shops
Location-based shop discovery

👑 For Admin
Add/Edit shops with complete details
Manage products with images
View user registrations
Website settings control

📱 Responsive Design
Works on mobile, tablet, desktop
Touch-friendly interface
Auto-adjusts layout

🎨 Design Highlights
Color Theme: Purple (#8e44ad)
Compact Cards: 3 per line with images
Favorites Modal: 600px width, scrollable
Location Status: Green when active

🔧 Technical Details
No Database Needed: Uses localStorage
No Server Required: Works offline
Modern JavaScript: ES6+ features
Clean CSS: Flexbox/Grid layout

📱 Mobile First
Mobile-optimized interface
Swipe-friendly navigation
Fast loading
Offline capabilities

🎯 Perfect For
Local fashion shops in Bareilly
Small business owners
Community marketplaces
Learning web development

📞 Contact Support
WhatsApp: +91 7668544517
Gmail: shariqshariq190@gmail.com
Location: Bareilly, Uttar Pradesh