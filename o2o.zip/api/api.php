<?php
header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, POST, PUT, DELETE');
header('Access-Control-Allow-Headers: Content-Type');

// Database configuration
$host = 'localhost';
$dbname = 'fashion_hub';
$username = 'root';
$password = '';

try {
    // Connect to database
    $pdo = new PDO("mysql:host=$host;dbname=$dbname;charset=utf8", $username, $password);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    
    // Get all active products with shop details
    $query = "
        SELECT 
            p.*,
            s.name as shop_name,
            s.owner_name,
            s.address as shop_address,
            s.location_area as location,
            s.location_code,
            s.distance_km as distance,
            s.phone,
            s.whatsapp,
            s.shop_type
        FROM products p
        JOIN shops s ON p.shop_id = s.id
        WHERE p.is_active = TRUE AND s.is_active = TRUE
        ORDER BY p.created_at DESC
    ";
    
    $stmt = $pdo->query($query);
    $products = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    echo json_encode([
        'success' => true,
        'count' => count($products),
        'products' => $products
    ]);
    
} catch(PDOException $e) {
    echo json_encode([
        'success' => false,
        'error' => 'Database error: ' . $e->getMessage()
    ]);
}
?>