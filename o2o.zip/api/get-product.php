<?php
header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');

// Include database connection
require_once '../config/database.php';

try {
    // Get all active products with shop details
    $query = "
        SELECT 
            p.*,
            s.name as shop_name,
            s.owner_name,
            s.address as shop_address,
            s.location_area as location,
            s.location_code,
            s.distance_km as distance,
            s.phone,
            s.whatsapp,
            s.shop_type
        FROM products p
        JOIN shops s ON p.shop_id = s.id
        WHERE p.is_active = 1 AND s.is_active = 1
        ORDER BY p.created_at DESC
    ";
    
    $stmt = $pdo->query($query);
    $products = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    echo json_encode([
        'success' => true,
        'count' => count($products),
        'products' => $products,
        'timestamp' => date('Y-m-d H:i:s')
    ]);
    
} catch(PDOException $e) {
    echo json_encode([
        'success' => false,
        'error' => 'Database error: ' . $e->getMessage(),
        'products' => []
    ]);
}
?>