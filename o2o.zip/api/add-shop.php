<?php
header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: POST');
header('Access-Control-Allow-Headers: Content-Type');

// Include database connection
require_once '../config/database.php';

// Get POST data
$data = json_decode(file_get_contents('php://input'), true);

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    try {
        // Prepare SQL statement
        $sql = "INSERT INTO shops (name, owner_name, address, location_area, location_code, distance_km, phone, whatsapp, shop_type, category) 
                VALUES (:name, :owner_name, :address, :location_area, :location_code, :distance_km, :phone, :whatsapp, :shop_type, :category)";
        
        $stmt = $pdo->prepare($sql);
        
        // Bind parameters
        $stmt->bindParam(':name', $data['name']);
        $stmt->bindParam(':owner_name', $data['owner_name']);
        $stmt->bindParam(':address', $data['address']);
        $stmt->bindParam(':location_area', $data['location_area']);
        $stmt->bindParam(':location_code', $data['location_code']);
        $stmt->bindParam(':distance_km', $data['distance_km']);
        $stmt->bindParam(':phone', $data['phone']);
        $stmt->bindParam(':whatsapp', $data['whatsapp']);
        $stmt->bindParam(':shop_type', $data['shop_type']);
        $stmt->bindParam(':category', $data['category']);
        
        // Execute query
        if ($stmt->execute()) {
            $shopId = $pdo->lastInsertId();
            
            echo json_encode([
                'success' => true,
                'message' => 'Shop added successfully!',
                'shop_id' => $shopId,
                'data' => $data
            ]);
        } else {
            echo json_encode([
                'success' => false,
                'error' => 'Failed to add shop'
            ]);
        }
        
    } catch(PDOException $e) {
        echo json_encode([
            'success' => false,
            'error' => 'Database error: ' . $e->getMessage()
        ]);
    }
} else {
    echo json_encode([
        'success' => false,
        'error' => 'Invalid request method'
    ]);
}
?>