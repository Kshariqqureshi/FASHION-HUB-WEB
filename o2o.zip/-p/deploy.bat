#!/bin/bash
# Fashion Hub Deployment Script

echo "Creating deployment package..."

# Create zip file
zip -r fashion-hub-project.zip . \
  -x "*.git*" \
  -x "node_modules/*" \
  -x "*.env" \
  -x "*.log" \
  -x ".DS_Store" \
  -x "deploy.sh"

echo "Package created: fashion-hub-project.zip"
echo "Upload this file to Netlify or your hosting provider"