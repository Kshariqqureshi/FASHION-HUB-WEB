# Install XAMPP/WAMP
# Start Apache and MySQL
# Import database.sql
# Place project in htdocs/www