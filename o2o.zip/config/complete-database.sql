-- fashion_hub_database.sql
-- Run this in phpMyAdmin to create database

CREATE DATABASE IF NOT EXISTS fashion_hub;
USE fashion_hub;

-- Shops table
CREATE TABLE shops (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(200) NOT NULL,
    owner_name VARCHAR(100) NOT NULL,
    address TEXT NOT NULL,
    location_area VARCHAR(50) NOT NULL,
    location_code VARCHAR(20) NOT NULL,
    distance_km DECIMAL(4,2) NOT NULL DEFAULT 1.5,
    phone VARCHAR(10) NOT NULL,
    whatsapp VARCHAR(10) NOT NULL,
    shop_type VARCHAR(20) NOT NULL DEFAULT 'retail',
    category VARCHAR(20) NOT NULL DEFAULT 'all',
    is_active BOOLEAN DEFAULT TRUE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);

-- Products table
CREATE TABLE products (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(200) NOT NULL,
    shop_id INT NOT NULL,
    category VARCHAR(20) NOT NULL,
    price DECIMAL(10,2) NOT NULL,
    image_url TEXT,
    description TEXT,
    is_active BOOLEAN DEFAULT TRUE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (shop_id) REFERENCES shops(id) ON DELETE CASCADE,
    INDEX idx_category (category),
    INDEX idx_shop (shop_id)
);

-- Users table
CREATE TABLE users (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    mobile VARCHAR(10) UNIQUE NOT NULL,
    password VARCHAR(255) NOT NULL,
    location VARCHAR(100),
    last_login TIMESTAMP NULL,
    is_active BOOLEAN DEFAULT TRUE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Admin users table
CREATE TABLE admin_users (
    id INT AUTO_INCREMENT PRIMARY KEY,
    username VARCHAR(50) UNIQUE NOT NULL,
    password VARCHAR(255) NOT NULL,
    full_name VARCHAR(100) NOT NULL,
    email VARCHAR(100),
    role VARCHAR(20) DEFAULT 'admin',
    last_login TIMESTAMP NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Insert default admin user (password: admin123)
INSERT INTO admin_users (username, password, full_name, email, role) VALUES
('admin', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'Administrator', 'admin@fashionhub.com', 'super_admin');

-- Insert sample shops
INSERT INTO shops (name, owner_name, address, location_area, location_code, distance_km, phone, whatsapp, shop_type, category) VALUES
('Trendy Fashions', 'Rahul Verma', 'Shop No. 12, Crossroad Mall, Civil Lines, Bareilly', 'Civil Lines', 'civil', 0.8, '9876543210', '9876543210', 'boutique', 'men'),
('Ethnic Wear Hub', 'Priya Sharma', 'Rampur Garden Market, Near Big Bazaar, Bareilly', 'Rampur Garden', 'rampur', 1.5, '9876543211', '9876543211', 'retail', 'women'),
('Footwear Zone', 'Amit Patel', '32/22, Subhash Nagar Market, Bareilly', 'Subhash Nagar', 'subhash', 1.8, '9876543212', '9876543212', 'brand', 'footwear'),
('Campus Fashion', 'Vikram Singh', 'Opp. Bareilly College Gate No. 1, College Road, Bareilly', 'Bareilly College Area', 'college', 0.5, '9876543215', '9876543215', 'retail', 'men');

-- Insert sample products
INSERT INTO products (name, shop_id, category, price, image_url, description) VALUES
('Men\'s Formal Shirt', 1, 'men', 1299.00, 'https://images.unsplash.com/photo-1596755094514-f87e34085b2c?ixlib=rb-4.0.3&auto=format&fit=crop&w=500&q=80', 'Premium cotton formal shirt for men'),
('Women\'s Silk Saree', 2, 'women', 2999.00, 'https://images.unsplash.com/photo-1566878980327-e2d6ad13b75c?ixlib=rb-4.0.3&auto=format&fit=crop&w=500&q=80', 'Traditional silk saree with elegant design'),
('Sports Shoes', 3, 'footwear', 2499.00, 'https://images.unsplash.com/photo-1542291026-7eec264c27ff?ixlib=rb-4.0.3&auto=format&fit=crop&w=500&q=80', 'Comfortable sports shoes for daily wear'),
('College Special Jeans', 4, 'men', 1499.00, 'https://images.unsplash.com/photo-1542272604-787c3835535d?ixlib=rb-4.0.3&auto=format&fit=crop&w=500&q=80', 'Trendy jeans specially for college students');

-- Create views
CREATE VIEW shop_products_view AS
SELECT s.*, COUNT(p.id) as product_count
FROM shops s
LEFT JOIN products p ON s.id = p.shop_id AND p.is_active = TRUE
WHERE s.is_active = TRUE
GROUP BY s.id;

CREATE VIEW active_products_view AS
SELECT p.*, s.name as shop_name, s.owner_name, s.location_area, s.phone, s.whatsapp
FROM products p
JOIN shops s ON p.shop_id = s.id
WHERE p.is_active = TRUE AND s.is_active = TRUE;

-- Show tables
SELECT 'Database created successfully!' as message;