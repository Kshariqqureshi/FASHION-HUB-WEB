<?php
// database.php - MySQL Connection File
$host = 'localhost';
$dbname = 'fashion_hub';
$username = 'root';
$password = '';

try {
    $pdo = new PDO("mysql:host=$host;dbname=$dbname;charset=utf8", $username, $password);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    // echo "Database connected successfully!";
} catch(PDOException $e) {
    die("Connection failed: " . $e->getMessage());
}

// Function to save data to localStorage (for demo)
function saveToLocalStorage($key, $data) {
    echo "<script>
        localStorage.setItem('$key', JSON.stringify(" . json_encode($data) . "));
    </script>";
}

// Function to get shops from database
function getShopsFromDB($pdo) {
    $stmt = $pdo->query("SELECT * FROM shops WHERE is_active = 1 ORDER BY created_at DESC");
    return $stmt->fetchAll(PDO::FETCH_ASSOC);
}

// Function to get products from database
function getProductsFromDB($pdo) {
    $stmt = $pdo->query("
        SELECT p.*, s.name as shop_name, s.owner_name, s.location_area, s.phone, s.whatsapp 
        FROM products p 
        JOIN shops s ON p.shop_id = s.id 
        WHERE p.is_active = 1 AND s.is_active = 1 
        ORDER BY p.created_at DESC
    ");
    return $stmt->fetchAll(PDO::FETCH_ASSOC);
}
?>